.macro store value,target
 LDA #value
 STA target
.endmacro
reset:
 SEI
 CLD
 LDX #$FF
 TXS
 store 0,PPUCTRL
 store 0,PPUMASK
 LDA data
 STA $0000
loop:
 JMP loop
nmi:
 RTI
irq:
 RTI
