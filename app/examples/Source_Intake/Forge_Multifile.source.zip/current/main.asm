; Forge-6502-v1 multi-file NROM example
.include "src/constants.inc"
.org $C000
.include "src/boot.asm"
data:
.incbin "assets/message.bin"
.org $FFFA
.word nmi,reset,irq
