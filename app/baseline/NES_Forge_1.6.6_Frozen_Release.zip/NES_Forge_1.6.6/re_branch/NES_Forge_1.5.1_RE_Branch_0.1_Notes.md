# NES Forge 1.5.1 — Reverse Engineering Branch 0.1 Final

## Purpose

This is an experimental reverse-engineering branch built on the validated NES Forge 1.5.1 Integration Hotfix. It is intentionally separate from the 1.6 World Authoring mainline. The branch adds a non-destructive cartridge analysis workspace without changing the existing Scene/CHR/Sprite/Audio/Animation/Build/Emulator workflow.

## RE Mode

The new **RE MODE** tab provides:

- physical PRG bank/unit map
- mapper-aware CPU address context selection for each physical PRG unit
- flow-following 6502 disassembly using the existing official-opcode decoder
- incoming xrefs within the selected physical-bank/CPU-window context
- discovered JSR/routine entry points
- direct PPU/APU/I/O register reference summaries
- APU/PPU-related routine candidate tags
- printable-string candidates
- palette-like byte-table candidates
- in-bank pointer-table candidates
- physical CHR-ROM bank browser
- explicit **Send → BG** / **Send → Sprite** actions
- physical-address labels and comments
- cartridge-wide notes
- analysis JSON export through the shared Save As workflow
- optional runtime execution coverage recorded by the existing emulator

## Physical bank model

The RE workspace deliberately distinguishes a CPU address from a physical cartridge offset. A CPU address such as `$8000` can refer to different ROM bytes after bank switching.

The current physical analysis granularity is:

- MMC3 / mapper 4: 8 KB PRG units
- NROM/CNROM/MMC1/UxROM: 16 KB PRG units for analysis
- AxROM/Color Dreams/GxROM: 32 KB PRG units

For bank-switchable mappers, a physical unit can be analyzed under more than one plausible CPU base. **Scan Entire Cartridge** evaluates the available CPU contexts and records the strongest heuristic context as `bestBase` rather than blindly assuming one fixed address.

## Runtime coverage

**Record Runtime** samples the CPU PC before each emulated instruction and translates it to the physical PRG offset currently mapped by the emulator. Coverage is stored per ROM signature and physical address.

0.1 Final hardening adds:

- runtime-observed physical PCs as additional static-analysis seeds
- live coverage highlighting derived from the current session rather than stale cached rows
- physical-bank execution totals in the bank map
- scan-context scoring that gives strong weight to observed execution
- scan summaries persisted with the RE workspace

Coverage is evidence from NES Forge's experimental emulator. It is not proof of cycle-perfect behavior on original hardware.

## Data-candidate hardening

The final 0.1 pass filters string/palette/pointer candidates away from bytes already classified as reachable code. Candidate and annotation offsets also create data-line boundaries so navigation and labels land on the intended physical byte instead of the start of an arbitrary 8-byte display chunk.

## Annotations and persistence

Labels and comments are keyed by **physical PRG offset**, not only CPU address. This keeps annotations attached to the same ROM bytes when that physical bank is inspected in a different CPU window.

The project schema retains RE data under a separate `reWorkspace` record. It includes:

- ROM-signature sessions
- labels
- comments
- notes
- preferred bank contexts
- runtime coverage
- bank execution counts
- persisted cartridge scan summary

Use **Preserve ROM in Project** if the actual ROM bytes should travel with the NES Forge project. Merely loading a ROM into the emulator does not automatically embed it in the project.

## Non-destructive boundary

RE analysis does not modify the game-authoring workspace. The only deliberate bridge into authored assets is **Send → BG** or **Send → Sprite**, which asks for confirmation and replaces the corresponding CHR bank of the active non-raster scene.

Native runtime-raster captures remain protected from direct bank replacement.

## Known limitations

This is the first analysis slice, not a complete decompiler/debugger.

Not yet implemented:

- automatic whole-cartridge source reconstruction
- guaranteed cross-bank control-flow resolution
- mapper-state timeline / bank-switch event visualization
- indirect-call resolution beyond simple candidate tables
- user-defined code/data/structure types
- symbol propagation across multiple bank contexts
- call graph visualization
- RAM variable naming/watch lists
- breakpoints and memory watchpoints in RE Mode
- music-driver/song structure reconstruction
- map/metatile format reconstruction
- analysis JSON import/merge
- NES 2.0 or unsupported mapper analysis

MMC1 can operate in 16 KB or 32 KB PRG modes; 0.1 analyzes physical 16 KB units and plausible CPU contexts rather than attempting to reconstruct every historical mapper state statically.

## Validation

The final branch HTML SHA-256 is:

`80f3b19876bfdfd4a0f0cfbb218bfdcbed0eee0938e43607dc8a0dfe41f106c1`

### Final branch reruns

- Core editor/build: **56 / 56**
- Runtime capture/raster: **43 / 43**
- CHR + Save As: **40 / 40**
- Foundation compatibility (branch identity adjusted): **16 / 16**
- 1.5.1 cross-tab integration: **60 / 60**
- RE-specific analysis suite: **16 / 16**
- RE emulator/coverage suite: **6 / 6**

**Total counted branch checks: 237 / 237.**

The inherited 1.5.1 Integration Hotfix baseline was **249 / 249** before branching.

A separate long-sequence stress run performed 20 seconds of MMC1 playback, repeated pause/resume activity, 6× CPU throttling, reset/reload, exact Runtime Capture, and Hybrid Capture. Playback measured about **58.18 FPS** in that run; subsequent capture validation remained **0 background / 0 composite differing pixels out of 61,440**, with no uncaught browser errors.

Automated fixtures are original synthetic diagnostic ROMs. No commercial ROM dump is included in this package.
