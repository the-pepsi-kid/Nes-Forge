#!/usr/bin/env node
'use strict';
// Engineering replay only. Users create these assets with NES Forge's ordinary
// editor tabs, or open the supplied editable example. No user script is needed.
const fs=require('node:fs'),path=require('node:path');
const {runNativeAuthoring}=require('../tests/native-authoring166.cjs');
const root=path.resolve(__dirname,'..');
(async()=>{
  const html=path.resolve(process.argv[2]||path.join(root,'mainline/NES_Forge_1.6.6_No_Code_Workflow.html'));
  const result=await runNativeAuthoring(html,{progress:console.log}),out=path.join(root,'examples');fs.mkdirSync(out,{recursive:true});
  for(const [name,value]of [['Scout_Authored_in_Editor_1.6.6.nesforge.json',result.originalProject],['Scout_Reopened_Edited_1.6.6.nesforge.json',result.editedProject],['Native_Authoring_Evidence.json',result.evidence]])fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
  fs.writeFileSync(path.join(out,'Scout_Authored_in_Editor_1.6.6.nes'),result.originalRom);fs.writeFileSync(path.join(out,'Scout_Reopened_Edited_1.6.6.nes'),result.editedRom);
  console.log('Created native editor authored Scout, reopened/edited example and complete action evidence. No manual browser QA claim.');
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
