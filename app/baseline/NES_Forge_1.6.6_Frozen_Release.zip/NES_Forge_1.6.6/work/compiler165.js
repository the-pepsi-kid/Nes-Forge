/* NES Forge 1.6.5: compile linked authoring assets into a bounded room runtime. */
(()=>{
'use strict';
const F=window.Forge165=window.Forge165||{};
const eventBits={attack_start:1,attack_end:2,footstep:4,sound:8,custom:16};
const propertyNames=['Empty','Solid','Platform','Ladder','Hazard','Water','Slope Left','Slope Right'];
const fail=message=>{throw Error('First Playable Room: '+message);};
function integer(value,min,max,label){if(!Number.isInteger(value)||value<min||value>max)fail(label+' must be an integer from '+min+' through '+max);return value;}
function selectedEntries(){return S.scenes.map((sc,index)=>({sc,index,order:clamp(sc.buildOrder??index,0,9999,index)})).filter(e=>e.sc.buildInclude!==false).sort((a,b)=>a.order-b.order||a.index-b.index);}
function validateRoom(room){
  if(room.raster)fail('The selected room is a raster capture. Create a lossless static copy first.');
  if(room.sceneType!=='sideview')fail('The selected room must use the Sideview scene type.');
  if(room.scrollDir!=='none'||room.view?.w!==256||room.view?.h!==240||(room.view?.x||0)!==0||(room.view?.y||0)!==0||(room.view?.followEnt??-1)>=0)fail('The selected room needs a fixed 256×240 camera at 0,0, no scrolling, and no camera follow entity.');
}
function collisionMap(room,linkedRoom){
  if(!Array.isArray(room.nt)||room.nt.length!==960)fail('The selected room needs a complete 32×30 nametable.');
  const result=room.nt.map(tile=>room.tileProps?.[tile]??0),definitions=new Map((linkedRoom.metatiles||[]).map(m=>[m.id,m]));
  // Linked metatile collision is independent of raw tile properties and must win.
  for(let cell=0;cell<240;cell++){
    const id=linkedRoom.metaMap?.[cell];if(id==null||id<0)continue;
    const definition=definitions.get(id);if(!definition)fail('A linked room cell references missing metatile '+id+'.');
    if(!Array.isArray(definition.collision)||definition.collision.length!==4)fail('Metatile '+id+' needs four collision quadrants.');
    const row=Math.floor(cell/16)*2,column=(cell%16)*2;
    for(let q=0;q<4;q++)result[(row+(q>>1))*32+column+(q&1)]=definition.collision[q];
  }
  result.forEach((value,index)=>{
    if(value!==0&&value!==1)fail('Collision at tile '+(index%32)+','+Math.floor(index/32)+' uses '+(propertyNames[value]||('property '+value))+'. This runtime supports Empty and Solid tiles.');
  });
  return result;
}
function normalizeBoxes(boxes,label){
  if(!Array.isArray(boxes)||boxes.length>4)fail(label+' supports at most four boxes per frame.');
  return boxes.map((box,index)=>{
    const name=label+' box '+(index+1),x=integer(box.x,-64,63,name+' X'),y=integer(box.y,-64,63,name+' Y'),w=integer(box.w,1,64,name+' width'),h=integer(box.h,1,64,name+' height');
    if(x+w>127||y+h>127)fail(name+' extends outside the runtime range.');
    return {x,y,w,h};
  });
}
function rowCounts(pieces,offset=0){
  const rows=new Map();
  for(const piece of pieces)for(let y=offset+piece.y;y<offset+piece.y+8;y++)rows.set(y,(rows.get(y)||0)+1);
  return rows;
}
function actorFrames(actor){return actor?Object.values(actor.animations).flatMap(a=>a.frames):[];}
function validateOAM(spec){
  const playerFrames=actorFrames(spec.player),targetFrames=actorFrames(spec.target);
  const playerCount=Math.max(0,...playerFrames.map(f=>f.pieces.length)),targetCount=Math.max(0,...targetFrames.map(f=>f.pieces.length));
  if(spec.staticOAM.length+playerCount+targetCount>64)fail('Static room sprites plus player and target frames exceed 64 hardware sprites.');
  const playerPeak=Math.max(0,...playerFrames.flatMap(f=>[...rowCounts(f.pieces).values()]));
  const staticRows=rowCounts(spec.staticOAM),targetRows=new Map();
  for(const frame of targetFrames)for(const [row,count] of rowCounts(frame.pieces,spec.target.y))targetRows.set(row,Math.max(targetRows.get(row)||0,count));
  let peak=0,peakRow=0;
  for(let y=0;y<240;y++){
    const count=playerPeak+(staticRows.get(y)||0)+(targetRows.get(y)||0);
    if(count>peak){peak=count;peakRow=y;}
  }
  if(peak>8)fail('The player, target, and static room sprites can need '+peak+' sprites on scanline '+peakRow+'; NES hardware allows eight. Reduce overlapping sprite pieces.');
}
function validateSpawn(player,physics,collision){
  const left=player.x-physics.bodyWidth/2,top=player.y-physics.bodyHeight,right=left+physics.bodyWidth,bottom=player.y;
  if(left<0||right>256||top<0||bottom>240)fail('The player body must start inside the 256×240 room. Its entity X/Y is the center of its feet.');
  for(let y=Math.floor(top/8);y<=Math.floor((bottom-1)/8);y++)for(let x=Math.floor(left/8);x<=Math.floor((right-1)/8);x++)if(collision[y*32+x])fail('The player body starts inside a solid tile at '+x+','+y+'. Move the feet origin above the floor.');
}
function compileGameplay(baseRom,config){
  if(!config||config.mode!=='single-room')fail('Select First Playable Room mode before compiling gameplay.');
  F.config?.validate(config,{references:true});
  if(document.getElementById('codeInput')?.value.trim())fail('Custom assembly is incompatible with First Playable Room mode. Keep it in Scene Viewer / Custom mode or save it separately before clearing it.');
  const header=parseRomHeader(baseRom);
  if(header.mapper!==0||header.prgSize!==16384||header.chrSize!==8192||header.trainer)fail('Gameplay compilation requires the current packed 16 KB NROM build with 8 KB CHR.');
  const entries=selectedEntries(),sceneIndex=entries.findIndex(e=>e.sc.id===config.sceneId);
  if(sceneIndex<0)fail('Include the selected gameplay room in the Build Scene Set.');
  const room=entries[sceneIndex].sc;validateRoom(room);
  const prg=baseRom.subarray(header.headerSize,header.headerSize+header.prgSize),info=Forge161.build.inspectWorldRom(prg,header.prgSize);
  if(!info.extension||info.sceneCount!==entries.length)fail('Packed ROM scenes do not match the current Build Scene Set. Rebuild the project.');
  const linked=Forge163.build.readRomAssets(baseRom);
  if(linked?.version!==2)fail('The packed ROM needs MS16 v2 entity animation bindings.');
  if(linked.sceneEntityCounts.length!==entries.length||entries.some((e,i)=>e.sc.entities.length!==linked.sceneEntityCounts[i]))fail('Packed entity counts do not match the current room entities. Rebuild the project.');
  const packedScenes=extractScenes(prg,header.prgSize);
  if(packedScenes.length!==entries.length)fail('The packed room scene records are incomplete. Rebuild the project.');
  const playerIndex=room.entities.findIndex(e=>e.id===config.playerId),targetIndex=config.targetId?room.entities.findIndex(e=>e.id===config.targetId):-1;
  if(playerIndex<0||room.entities[playerIndex].type!=='player')fail('Choose a player entity from the selected room.');
  if(config.targetId&&(targetIndex<0||targetIndex===playerIndex||!['enemy','npc'].includes(room.entities[targetIndex].type)))fail('The optional training target must be a different Enemy or NPC entity in this room.');
  const sceneAddress=0xD000+sceneIndex*0x600,sceneOffset=sceneAddress-0xC000,roomPalette=Array.from(prg.subarray(sceneOffset+0x410,sceneOffset+0x420));
  const framesById=new Map(linked.frames.map(frame=>[frame.id,frame])),animationsById=new Map(linked.animations.map(animation=>[animation.id,animation])),animationCache=new Map();
  function checkPalette(buildSceneIndex,row,label){
    integer(buildSceneIndex,0,entries.length-1,label+' source scene');integer(row,0,3,label+' palette row');
    const source=entries[buildSceneIndex].sc;
    for(let color=1;color<=3;color++)if(source.sprPal?.[row]?.[color]!==roomPalette[row*4+color])fail(label+' uses sprite palette '+row+' from "'+source.name+'" that differs from the room. Match visible colors 1–3 before building.');
  }
  function normalizePieces(frame,label){
    const result=[];
    const add=(x,y,tile,attr)=>{integer(x,-64,63,label+' piece X');integer(y,-64,63,label+' piece Y');integer(tile,0,255,label+' linked tile');result.push({x,y,tile,attr});};
    if(frame.metaspriteId){
      const asset=framesById.get(frame.metaspriteId);if(!asset)fail(label+' references a missing linked metasprite.');
      for(const piece of asset.pieces){
        checkPalette(asset.buildSceneIndex,piece.pal,label);
        const x=piece.x-asset.originX,y=piece.y-asset.originY,attr=piece.pal|(piece.behind?32:0)|(piece.flipH?64:0)|(piece.flipV?128:0);
        if(asset.spriteMode===16){add(x,y,piece.flipV?piece.tile2:piece.tile,attr);add(x,y+8,piece.flipV?piece.tile:piece.tile2,attr);}
        else add(x,y,piece.tile,attr);
      }
    }else{
      checkPalette(frame.buildSceneIndex,0,label);add(-4,-4,frame.tileIdx,0);
    }
    if(result.length>24)fail(label+' needs '+result.length+' hardware sprites; each actor frame supports at most 24.');
    return result;
  }
  function compileAnimation(id,label){
    if(animationCache.has(id))return animationCache.get(id);
    const animation=animationsById.get(id);if(!animation)fail(label+' references a missing linked animation.');
    if(!animation.frames.length||animation.frames.length>64)fail(label+' supports 1–64 animation frames.');
    const compiled={loop:animation.loop!==false,frames:animation.frames.map((frame,index)=>{
      const frameLabel=label+' frame '+(index+1);
      let eventMask=0;for(const event of frame.events||[])eventMask|=eventBits[event.type]||0;
      return {duration:integer(frame.duration,1,255,frameLabel+' duration'),pieces:normalizePieces(frame,frameLabel),hitboxes:normalizeBoxes(frame.hitboxes||[],frameLabel+' hitboxes'),hurtboxes:normalizeBoxes(frame.hurtboxes||[],frameLabel+' hurtboxes'),eventMask};
    })};
    animationCache.set(id,compiled);return compiled;
  }
  function compileActor(index,role){
    const source=room.entities[index],packed=linked.entities.find(e=>e.buildSceneIndex===sceneIndex&&e.entityIndex===index);
    if(!packed||packed.id!==source.id)fail('Packed '+role+' identity does not match the selected entity. Rebuild the project.');
    const binding=packed.animationBinding;if(!binding?.states?.length)fail('The '+role+' needs animation state bindings in Entity Studio.');
    const states=new Map(binding.states.map(state=>[state.state,state.animationId])),animations={};
    if(role==='player'){
      for(const state of ['idle','walk','attack']){if(!states.has(state))fail('The player needs an "'+state+'" animation binding.');animations[state]=compileAnimation(states.get(state),'Player '+state);}
      if(animations.attack.loop)fail('The player attack animation must be nonlooping.');
      if(states.has('jump'))animations.jump=compileAnimation(states.get('jump'),'Player jump');
    }else{
      if(!states.has(binding.defaultState))fail('The target needs a valid default animation state.');
      animations.idle=compileAnimation(states.get(binding.defaultState),'Target default');
      if(states.has('hurt')){animations.hurt=compileAnimation(states.get('hurt'),'Target hurt');if(animations.hurt.loop)fail('The target hurt animation must be nonlooping.');}
    }
    // Position bytes come from the successfully built scene record, not a new remap.
    const entityOffset=sceneOffset+0x540+index*8;
    return {x:prg[entityOffset+1],y:prg[entityOffset+2],facing:binding.facing==='left'?1:0,animations};
  }
  const physics={};for(const key of ['moveSpeed','jumpSpeed','gravity','maxFallSpeed','bodyWidth','bodyHeight'])physics[key]=config[key];
  const count=integer(prg[sceneOffset+0x420],0,64,'Static OAM count'),staticOAM=[];
  for(let index=0;index<count;index++){const at=sceneOffset+0x421+index*4;staticOAM.push({x:prg[at+3],y:prg[at]+1,tile:prg[at+1],attr:prg[at+2]});}
  const spec={sceneAddress,sceneIndex,playerIndex,targetIndex,collision:collisionMap(room,packedScenes[sceneIndex]),physics,player:compileActor(playerIndex,'player'),target:targetIndex<0?null:compileActor(targetIndex,'target'),staticOAM,warnings:[]};
  validateSpawn(spec.player,physics,spec.collision);validateOAM(spec);
  if(!spec.player.animations.attack.frames.some(frame=>frame.hitboxes.length))spec.warnings.push('The player attack has no hitboxes, so it cannot hit the training target.');
  if(spec.target&&!actorFrames(spec.target).some(frame=>frame.hurtboxes.length))spec.warnings.push('The training target has no hurtboxes, so it cannot register hits.');
  return spec;
}
F.compileGameplay=compileGameplay;
})();
