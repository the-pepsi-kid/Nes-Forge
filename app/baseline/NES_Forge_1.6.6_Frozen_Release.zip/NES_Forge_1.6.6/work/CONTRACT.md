# 1.6.5 First Playable Room contract

Baseline is frozen 1.6.4 SHA256 `43564ce820d6db4b50d54d895ecfecd60fdc28a1dce76422f1bca2fdcddd2f7c`. Append layers; never modify emulator/runtime capture/Save As code. Namespace `window.Forge165`.

## Project model and UI

Project schema **8**, foundation **1.6.5**, optional legacy `gameplay` becomes default object:
`{mode:'viewer',sceneId:'',playerId:'',targetId:'',moveSpeed:2,jumpSpeed:9,gravity:1,maxFallSpeed:6,bodyWidth:12,bodyHeight:22}`.

Modes `viewer` / `single-room`. IDs are strings <=255 UTF-8 bytes, empty means unselected/optional target. Integer limits: moveSpeed1..4, jumpSpeed1..12, gravity1..3, maxFallSpeed1..8, bodyWidth2..32 (even), bodyHeight2..48. Gameplay body is fixed origin-relative rectangle `x=-bodyWidth/2,y=-bodyHeight,w=bodyWidth,h=bodyHeight`. Entity X/Y is the feet/center origin for gameplay. Viewer is the migration default and delegates to the existing build path.

`F.config.defaults()`, `validate(value,{references=false})`, `get()`, `set(key,value)`, `setAll(object)`; mutations snapshot once and notify. Missing references may save for repair but fail gameplay build. Current selected room must be in Build Scene Set, sideview, non-raster, fixed256×240 camera/no scroll. Exactly one chosen player of type player, optional distinct enemy/npc target. Custom ASM is incompatible with single-room mode and never cleared automatically.

UI in ROM build panel offers mode, room/player/target selects, integer physics/body fields, and Build & Play. Clear explanation that player position is feet origin, A=jump, B=attack, Start=restart. Existing scene viewer/custom modes remain usable. Editor UI controls do not expose engine addresses.

## Compiler API (compiler165.js)

`F.compileGameplay(baseRom,config) -> spec` reads linked MS16 v2 from a successfully built existing 16KB NROM. Uses source project only for selected identities and collision/palette validation. Fields:

```
{
 sceneAddress: 0xD000 + buildSceneIndex*0x600,
 sceneIndex, playerIndex, targetIndex, // targetIndex -1 when absent
 collision: Array(960), // 0 empty,1 solid; raw source tiles overridden by linked metatile quadrants
 physics: {moveSpeed,jumpSpeed,gravity,maxFallSpeed,bodyWidth,bodyHeight},
 player: {x,y,facing:0|1,animations:{idle,walk,attack,jump?}},
 target: null | {x,y,facing:0|1,animations:{idle,hurt?}},
 staticOAM:[{x,y,tile,attr}],
 warnings: []
}
```

Facing0=right,1=left. Each animation `{loop:boolean,frames:[{duration,pieces,hitboxes,hurtboxes,eventMask}]}`. Pieces are normalized hardware8×8 records `{x,y,tile,attr}` relative to actor origin. Expand8×16 pieces and preserve nonadjacent top/bottom/flipV semantics. Boxes `{x,y,w,h}`. Event mask: attack_start1,attack_end2,footstep4,sound8,custom16; observational runtime debug only. Damage is authoritative from current attack-frame hitboxes, with one target hit per attack.

Runtime limits: max64 frames per used animation; max24 hardware pieces per actor frame; max4 hitboxes/hurtboxes per frame; relative piece offsets and box origins -64..63, box dimensions1..64, total extents within -64..127. Used sprite palette rows from source must equal corresponding room rows (visible colors1..3); no silent recoloring. Empty/solid collision only; unsupported property values fail clearly. Static+actor total <=64 OAM; conservative worst-case row counts <=8 per scanline, otherwise clear error. All sources must be included as required by existing linker. Player requires idle/walk/attack states, attack nonlooping. Optional jump uses idle if absent. Target idle uses its authored default state; hurt optional nonlooping, otherwise hit flash alone. Keep all authoring metadata even when states aren't runtime-executed.

## Engine API (engine165.js)

`F.makeGameplayEngine(spec) -> {bytes,reset,nmi,irq,symbols,codeEnd,dataEnd}`.
`bytes` maps CPU `$8000` onward, length <=`0x3800` (ends before `$B800`). Suggested code `$8000..$9FFF`, compiled tables `$A000..$B7FF`; enforce all bounds. Engine owns numeric data encoding, uses official6502 instructions, isolated bounded emitter, and exports RAM symbols for tests.

Reserved `$B800..$BFFF` belongs to gameplay configuration metadata, owned by root/persistence. Root builder creates32KB NROM by copying legacy16KB PRG to `$C000..$FFFF`, putting engine bytes in lower bank, changing interrupt vectors, copying linked8KB CHR unchanged. Existing NFEX/WR16/MS16 block stays byte-identical. No user ASM substitutions. Preserve `_buildAndRunMode`, download path, stale-ROM clearing, errors.

Gameplay: reset uploads selected room with rendering disabled, initializes RAM/OAM, enables NMI. Main loop computes one update per NMI handshake; NMI performs bounded OAM DMA/register work, no long game logic in vblank. Read pad with documented physical mapping. Left/right simultaneous => no horizontal movement; face last unambiguous direction. A rising edge jumps only grounded, no auto-repeat. B rising edge starts one-shot attack only when not already attacking; one hit per swing. Start rising edge restarts actors/room state. Horizontal/vertical per-pixel collision prevents tunneling; grounded/ceiling/wall/bounds correct, gravity and terminal velocity. Idle/walk/jump/attack choose bound animations; current frame lasts duration ticks. Target stationary, hit counter and finite hurt/flash reaction then returns idle. Events expose entry mask/counter but do not execute audio/custom scripts. Left facing reflects art and boxes; offscreen pieces are hidden rather than byte-wrapped. Static room OAM remains decorative.

Export symbols for ready, ticks (or tickLo/tickHi), playerX/Y, velocityY, grounded, playerState, playerFrame, playerFacing, targetHits, targetHurtTimer, targetFrame, eventMask/eventCount if implemented, controller buttons/edge. Tests must execute actual bundled emulator via emuLoadRomData and emuRunFrame, not a JS physics approximation.

## Persistence/build integration (root)

v8 JSON/ZIP settings validated before legacy loader; delegate base asv7 then restore config. Missing legacy settings defaultviewer. Undo/reload preserve settings. New GP16 v1 record at exact `$B800`: four-byte magic, version byte1, u32 payload byte length, u32 CRC32, UTF8 JSON payload containing mode, build scene/player/target indices, physics. Decode validates CRC/bounds/indices before any import mutation. Old MS16/WR16 import preserved; after successful gameplay-ROM import settings remap to appended scene/entity IDs. Unknown/corrupt GP16 must fail atomically. Default viewer ROM stays unchanged.

Layer order: config165.js, compiler165.js, engine165.js, build165.js, ui165.js, release165.js. Root owns config/build/assembly/release/demo/docs. Compiler agent owns compiler165.js; engine agent engine165.js; UI agent ui165.js. Test agent owns tests runner/new gameplay suite. All work under `nes_forge_1_6_5`.
