"""Assemble the standalone release without altering frozen core code."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
source=root/'baseline/NES_Forge_1.6.5_First_Playable_Room.html'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='aae0002a5b991d21260612177619ca696d4baef8ca00e08affc25cd193618bb8'
html=source.read_text(encoding='utf-8')
layers=['project166.js','placement166.js','ui166.js','release166.js']
available=[name for name in layers if (root/'work'/name).exists()]
code='\n\n'.join((root/'work'/name).read_text(encoding='utf-8') for name in available)
assert html.count('</script>')==1
html=html.replace('</script>','\n'+code+'\n</script>')
target=root/'mainline/NES_Forge_1.6.6_No_Code_Workflow.html'
target.write_text(html,encoding='utf-8',newline='\n')
print(target)
if len(available)!=len(layers):print('Pending layers: '+', '.join(n for n in layers if n not in available))
