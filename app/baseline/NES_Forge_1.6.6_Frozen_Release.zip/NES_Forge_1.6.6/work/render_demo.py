"""Export actual bundled-emulator pixels; no browser screenshot is claimed."""
from pathlib import Path
import json
from PIL import Image
root=Path(__file__).resolve().parents[1]
frame_bytes=256*240*4
image=Image.frombytes('RGBA',(256,240),(root/'work/demo_frame.rgba').read_bytes()).convert('RGB')
image.resize((768,720),Image.Resampling.NEAREST).save(root/'examples/Scout_Gameplay_Preview.png')
info=json.loads((root/'work/demo_replay.json').read_text(encoding='utf-8'))
data=(root/'work/demo_replay.rgba').read_bytes()
assert len(data)==info['frames']*frame_bytes
images=[Image.frombytes('RGBA',(256,240),data[i*frame_bytes:(i+1)*frame_bytes]).convert('RGB').resize((512,480),Image.Resampling.NEAREST) for i in range(info['frames'])]
images[0].save(root/'examples/Scout_Gameplay_Replay.gif',save_all=True,append_images=images[1:],duration=info['millisecondsPerFrame'],loop=0,optimize=True,disposal=2)
print('Exported gameplay framebuffer preview and replay.')
