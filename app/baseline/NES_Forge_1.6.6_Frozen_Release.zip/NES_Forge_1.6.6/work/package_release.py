"""Package the tested standalone release, demo, sources, and verification data."""
from pathlib import Path
import hashlib
import json
import zipfile
root=Path(__file__).resolve().parents[1]
html=root/'mainline/NES_Forge_1.6.6_No_Code_Workflow.html'
summary=json.loads((root/'test-results/Summary.json').read_text(encoding='utf-8'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(html)==summary['sha256'], 'Release differs from tested HTML'
assert summary['passed']==summary['total'], 'Tests are incomplete'
demo=json.loads((root/'examples/Native_Authoring_Evidence.json').read_text(encoding='utf-8'))
assert demo['htmlSha256']==summary['sha256'], 'Regenerate the demo against final HTML'
files=[]
for p in root.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(root).as_posix()
    if rel.startswith('work/legacy_workflow166/'):continue
    if rel.startswith('test-results/') and p.stem in {'ui166','workflow166','starter166'}:continue
    if rel=='SHA256SUMS.txt' or '__pycache__' in p.parts or p.suffix=='.rgba':continue
    if rel.startswith('tests/') and p.suffix=='.json' and p.name not in {'preserved-source.json','Baseline_Regression_Results.json'}:continue
    if rel.startswith('test-results/') and any(word in p.name for word in ['focused','isolated','partial']):continue
    if p.name.endswith('_harness.html'):continue
    if p.name.startswith('_'):continue
    files.append(p)
files.sort(key=lambda p:p.relative_to(root).as_posix())
checksums=root/'SHA256SUMS.txt';checksums.write_text(''.join(digest(p)+'  '+p.relative_to(root).as_posix()+'\n' for p in files))
target=root.parent/'NES_Forge_1.6.6_No_Code_Workflow_Release.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[checksums]:z.write(p,'NES_Forge_1.6.6/'+p.relative_to(root).as_posix())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    assert hashlib.sha256(z.read('NES_Forge_1.6.6/'+html.relative_to(root).as_posix())).hexdigest()==summary['sha256']
print(json.dumps({'archive':str(target),'files':len(files)+1,'bytes':target.stat().st_size,'htmlSha256':summary['sha256'],'passed':summary['passed'],'total':summary['total']},indent=2))
