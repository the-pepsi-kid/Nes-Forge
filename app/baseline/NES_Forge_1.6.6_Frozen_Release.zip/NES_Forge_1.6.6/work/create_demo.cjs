#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {loadForge}=require('../tests/harness.cjs');
const root=path.resolve(__dirname,'..'),cp=v=>JSON.parse(JSON.stringify(v));
const p=JSON.parse(fs.readFileSync(path.join(root,'examples/Forge_Scout_Demo_1.6.4.nesforge.json'),'utf8')),sc=p.scenes[0];
p.version=8;p.foundation='1.6.5';p.projectName='Forge Scout — First Playable Room';p.asmSource='';p.mapper=0;p.selEntity=0;
sc.name='Scout Training Room';sc.sceneType='sideview';sc.scrollDir='none';sc.view={x:0,y:0,w:256,h:240,followEnt:-1,hBorder:32,vBorder:24};sc.raster=null;sc.oam=[];sc.links=[];
sc.nt=Array(960).fill(0);sc.attr=Array(64).fill(0);sc.tileProps=Array(256).fill(0);sc.metaMap=Array(240).fill(-1);sc.metatiles=[];
sc.pal=[[15,9,25,41],[15,7,23,39],[15,1,17,33],[15,0,16,48]];
const tile=rows=>rows.map(row=>[...row].map(Number));
sc.chr[1]=tile(['33333333','22222222','11111111','11211111','11111111','11111211','11111111','11111111']);
sc.chr[2]=tile(['33333333','22222222','12111211','11111111','11211121','11111111','11112111','11111111']);
sc.chr[3]=tile(['33333333','22212221','22212221','11111111','12221222','12221222','12221222','11111111']);
sc.chr[4]=tile(['00000000','00000000','00010000','00121000','00010000','00000000','00000000','00000000']);
// Background landmarks use an empty collision tile.
for(const [x,y]of [[4,4],[12,6],[23,3],[28,10],[7,12],[19,9]])sc.nt[y*32+x]=4;
sc.tileProps[1]=sc.tileProps[2]=sc.tileProps[3]=1;
for(let y=26;y<30;y++)for(let x=0;x<32;x++)sc.nt[y*32+x]=y===26?1:2;
for(let y=17;y<26;y++){sc.nt[y*32]=3;sc.nt[y*32+31]=3;}
for(let x=10;x<16;x++)sc.nt[22*32+x]=1;
for(let x=19;x<25;x++)sc.nt[19*32+x]=1;
// A linked metatile section proves gameplay uses per-quadrant collision too.
sc.metatiles=[{id:1,name:'Solid training block',category:'terrain',tiles:[3,3,3,3],pal:1,collision:[1,1,1,1],flags:0}];
sc.metaMap[12*16+14]=1;for(const index of [24*32+28,24*32+29,25*32+28,25*32+29])sc.nt[index]=3;
const setPal=(tx,ty,pal)=>{const at=Math.floor(ty/4)*8+Math.floor(tx/4),shift=((ty%4>=2?1:0)*2+(tx%4>=2?1:0))*2;sc.attr[at]=(sc.attr[at]&~(3<<shift))|(pal<<shift);};
for(let y=0;y<30;y+=2)for(let x=0;x<32;x+=2)setPal(x,y,y>=26?1:2);setPal(28,24,1);
const player=sc.entities[0],target=sc.entities[1];Object.assign(player,{x:48,y:208,name:'Scout'});Object.assign(target,{x:208,y:208,name:'Training target'});target.animationBinding.defaultState='idle';
p.gameplay={mode:'single-room',sceneId:sc.id,playerId:player.id,targetId:target.id,moveSpeed:2,jumpSpeed:9,gravity:1,maxFallSpeed:6,bodyWidth:12,bodyHeight:22};
for(const key of ['chr','sprChr','nt','attr','pal','sprPal','tileProps','oam'])p[key]=cp(sc[key]);
const html=path.join(root,'baseline/NES_Forge_1.6.5_First_Playable_Room.html'),h=loadForge(html);h.context.demo=p;h.run('db_deserializeState(demo);window._buildAndRunMode=true');assert.equal(h.errors.length,0,h.errors.join('; '));
const project=h.json('projectData()');fs.writeFileSync(path.join(root,'examples/Forge_Scout_Demo_1.6.5.nesforge.json'),JSON.stringify(project));
if(process.argv.includes('--project-only')){console.log('Scout playable project prepared.');process.exit(0);}
const rom=h.run('buildNesRom()',15000);assert.ok(rom instanceof Uint8Array,h.errors.join('; '));fs.writeFileSync(path.join(root,'examples/Forge_Scout_Demo_1.6.5.nes'),rom);
fs.writeFileSync(path.join(root,'examples/Gameplay_Symbols.json'),JSON.stringify(h.json('({symbols:Forge165.lastBuild.symbols,codeEnd:Forge165.lastBuild.codeEnd,dataEnd:Forge165.lastBuild.dataEnd,record:Forge165.lastBuild.record})'),null,2)+'\n');
h.context.rom=rom;assert.equal(h.run('emuLoadRomData(rom,"Scout training room",0)',15000),true);h.run('S.tab="emu";clearEmuKeys();for(let i=0;i<12;i++)emuRunFrame()',20000);
const symbols=h.json('Forge165.lastBuild.symbols');h.context.symbols=symbols;assert.ok(h.run('emu.ram['+symbols.ready+']'));assert.equal(h.run('emu.opsMissed'),0);fs.writeFileSync(path.join(root,'work/demo_frame.rgba'),Buffer.from(h.run('emu.frameBuffer')));
const replay=[],trace=[];let frameNumber=0;
function advance(phase,count,names=[]){
  h.context.names=names;h.run('clearEmuKeys();for(const name of names)emuKeys[name]=true');
  for(let i=0;i<count;i++){
    h.run('{emuRunFrame();let work=0;while(emu.PC!==symbols.labels.main||emu.ram[symbols.frameReady]){cpuStep();if(++work>20000)throw Error("Demo runtime did not finish its update");}}',15000);
    if(frameNumber++%3===0)replay.push(Buffer.from(h.run('emu.frameBuffer')));
  }
  const sample=h.json('({x:emu.ram[symbols.playerX],y:emu.ram[symbols.playerY],grounded:emu.ram[symbols.grounded],hits:emu.ram[symbols.targetHits]})');trace.push({phase,...sample});return sample;
}
advance('Idle',24);advance('Approach platform',8,['ArrowRight']);
const landed=advance('Jump onto platform',16,['ArrowRight','KeyZ']);assert.equal(landed.y,176);assert.equal(landed.grounded,1);
advance('Stand on platform',12);advance('Walk off platform',20,['ArrowRight']);advance('Land on floor',18);
advance('Approach target',25,['ArrowRight']);const hit=advance('Attack target',22,['KeyX']);assert.equal(hit.hits,1);
advance('Recover',20);advance('Turn left',8,['ArrowLeft']);const missed=advance('Attack away from target',22,['KeyX']);assert.equal(missed.hits,1);advance('Restart',1,['Enter']);advance('Idle after restart',20);
fs.writeFileSync(path.join(root,'work/demo_replay.rgba'),Buffer.concat(replay));fs.writeFileSync(path.join(root,'work/demo_replay.json'),JSON.stringify({width:256,height:240,frames:replay.length,millisecondsPerFrame:50,trace},null,2)+'\n');
fs.writeFileSync(path.join(root,'test-results/Demo.json'),JSON.stringify({htmlSha256:require('node:crypto').createHash('sha256').update(fs.readFileSync(html)).digest('hex'),romBytes:rom.length,projectSchema:8,projectLoad:'pass',generatedGameplayBuild:'pass',actualEmulatorBoot:'pass',jumpOntoPlatform:'pass',attackTarget:'pass',facingAwayMiss:'pass',unsupportedOpcodes:h.run('emu.opsMissed'),browserScreenshot:false,trace},null,2)+'\n');
console.log('Scout demo: v8 project, gameplay ROM, actual emulator jump/landing/attack passed.');
