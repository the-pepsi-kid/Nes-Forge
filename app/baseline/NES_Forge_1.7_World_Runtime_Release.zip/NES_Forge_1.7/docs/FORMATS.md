# Format compatibility — 1.7

## Project schema 10

Current project JSON uses schema **10** and foundation **1.7**. The new top-level `worldRuntime` record contains `enabled`, `worldId`, `spawnId`, `playerSceneId`, `playerId`, `moveSpeed`, `jumpSpeed`, `gravity`, `maxFallSpeed`, `bodyWidth` and `bodyHeight`. Existing `gameplay` remains separate. Saves, full-project loads, recovery and history preserve both.

Schema 9’s serializer cannot preserve the new record. The actual frozen 1.6.7 editor must reject schema 10 before mutation. Explicit downgrade is unsupported; changing `foundation` or lowering `version` is not a conversion. Supported older projects migrate with World Runtime disabled when the record is absent. Strict shape validation rejects malformed settings while preserving unresolved saved IDs for repair. Build validation checks executable references and geometry.

The previous schema-9 unresolved-world-reference guarantee remains. The actual 1.6.6 schema-8 data-loss behavior is historical characterization, not supported downgrade behavior. Migration cannot restore values an earlier editor already deleted.

## ROM formats by backend

| Backend | Outer layout | Records |
| --- | --- | --- |
| World Runtime | NFORGE15 layout 4 | WG17 v1 checked compressed source and new generated world code/data |
| Packed viewer/custom, existing single-room | NFORGE15 layout 3 | NFEX v1, MT16 v1, WR16 v3, MS16 v2; single-room GP16 v1 |
| Unpacked custom | Existing custom layout | Existing assembly and direct CHR behavior |

The new outer layout is a format distinction, not a mapper. World output is ordinary iNES mapper 0 with 32 KB PRG and 8 KB CHR, no trainer. Its marker occupies CPU `$CFF0–$CFFF`; vectors occupy `$FFFA–$FFFF`. Generated code/data must end before `$CFF0`. The source record is allocated contiguously after the engine where it fits, or from `$D000`, without overlapping marker/vectors.

WG17 has a 64-byte versioned header followed by deterministic LZSS source bytes. Lengths, decoded-size bounds, header/source/engine/CHR checksums, record placement, vectors, flags and source schema are checked before clean opening. The decoded source limit is 8 MB; compressed source must also fit available PRG. Compression is storage for authored source, not a new execution or mapper feature.

The World record preserves the authored snapshot, including unrelated authored worlds/assets/settings, **except previously imported ROM bytes**, which are explicitly omitted to prevent recursive build/open growth. Open Forge ROM restores that source and retains the newly opened ROM as the original. Project JSON/ZIP remain full backups when previous original ROM bytes must also be retained.

New World ROMs use a dedicated decoder/replacement adapter. Append Import rejects them with Open Forge ROM guidance. Old supported ROMs continue through existing append/capture paths. Corrupt/unsupported recognized formats must reject before state/history/runtime/identity changes. The actual 1.6.7 application rejects the layout-4 marker instead of partially opening it.

## Preserved single-room format

| CPU region | Existing use |
| --- | --- |
| `$8000–$9FFF` | Single-room generated code, bounded to 8 KB |
| `$A000–$B7FF` | Collision/animation/pose/contact/event data, bounded to 6 KB |
| `$B800–$BFFF` | GP16 configuration reservation |
| `$C000–$CFFF` | Viewer/authoring metadata and layout-3 marker |
| `$D000 + n×$0600` | Packed scene blocks and following tile-property table |
| `$FFFA–$FFFF` | Interrupt vectors |

GP16 v1 remains strict UTF-8 JSON with length/CRC in its 2,048-byte reservation. MS16 v2 retains its nested v1 payload. WR16 v3 retains identities; older WR16 v1/v2 warnings remain when identities were never stored. No older codec is relabeled to imply the new World format.

Protected source/whole-ROM parity and compatibility tests are release gates. New format support does not establish general reverse engineering, arbitrary source recovery from foreign ROMs or independent NES hardware verification.
