# Real-browser acceptance — unverified

A permitted 1.7 Cloud Browser attempt to open the standalone candidate was rejected by URL security policy before the application could be inspected. `../checkpoints/1.7-browser-attempt.json` records the attempted candidate hash, rejection and absence of workaround/retry. The attempted build was mutable; its hash is not the final package hash. No browser pass is claimed.

The earlier 1.6.7 attempt remains historical evidence in `../checkpoints/browser-acceptance.json`.

All eight actions remain unverified for the current candidate. The additional new World controls are also unverified:

| Acceptance item | Status | Required observation in a permitted browser |
| --- | --- | --- |
| Blank startup | Unverified | Blank viewer art/data, World mode off, no starter or false saved identity |
| Recovery banner | Unverified | Checking protects retained recovery; Restore/Dismiss and invalid/delayed reads preserve correct state |
| Save | Unverified | Correct captured project/identity; delayed saves cannot mark later edits/replacements clean |
| Save As | Unverified | Native picker/download, gesture context, bytes and cancellation behave correctly |
| Project opening | Unverified | Supported JSON/ZIP and both playable ROM formats open correctly; invalid input is atomic; correct history policy |
| Build & Run | Unverified | Explicit mode/configuration is used; World controls and canvas display work; failed builds never play stale output |
| Run Original | Unverified | Retained original bytes play independently of current edits and generated build |
| Runtime capture | Unverified | Completed-frame background/sprites/provenance and scene-aware CHR/palettes remain correct and editable |

When a permitted browser is available, record the exact browser/OS/version and candidate hash with observations for each item. Include World sidebar selectors, keyboard focus, mode switching, screen/camera transitions, reopening, confirmation/cancel flows, normal editor widths and recovery reloads.

VM handler checks, controlled storage tests, source guards, whole-ROM comparison and bundled-emulator execution provide separate automated evidence. They do not prove actual browser layout, native file-picker behavior, browser timing or independent NES hardware accuracy. Never mark browser items passed by inference or bypass the established security boundary.

Completing browser acceptance does not authorize new features or another milestone.
