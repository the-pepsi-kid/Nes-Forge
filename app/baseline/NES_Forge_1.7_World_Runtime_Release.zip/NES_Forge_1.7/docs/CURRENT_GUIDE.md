# Current editor guide — 1.7

Use the existing editor tabs. Fresh startup is a blank viewer scene; World Runtime is off. New Project remains the existing blank single-room factory. Neither action automatically loads an example.

## Project actions

| Action | Behavior |
| --- | --- |
| Recovery banner | Restore or Dismiss retained recovery; checking/pending decisions protect old recovery from autosave |
| New Project | Blank single-room configuration with World mode off; replacement is undoable |
| Open Project | Validate before full replacement; ordinary opening clears history and preserves saved authoring |
| Save | Browser save with existing identity/revision guards |
| Save Project As / Export | Portable authoring backup, now schema 10; existing picker/download/cancel behavior |
| Open Forge ROM | Checked clean opening of supported legacy playable ROMs or new World ROMs; undoable, original bytes retained |
| Import ROM | Existing append/capture behavior for older supported ROMs; new World ROMs explicitly require Open Forge ROM |

CHR SHEET edits pixels; METATILES defines reusable terrain; WORLD paints maps and places rooms/markers/cameras. SCENE and ENTITY STUDIO place/bind entities; METASPRITES and ANIM author poses, frames and contacts; COLLISION sets tile behavior. Assembly remains optional.

## Build mode

| Selection | Generated behavior |
| --- | --- |
| World Runtime enabled in WORLD | One authored sideview player traverses reachable metatile worlds, screen boundaries and Up-activated links; world/player dependencies define the build |
| World Runtime off; single-room in SCENE → Gameplay | Existing fixed 256×240 Player/optional stationary Target runtime and legacy Build Scene Set |
| World Runtime off; viewer/custom | Existing packed viewer, packed custom assembly or unpacked custom assembly behavior |

Enabling World Runtime preserves the old gameplay choices while disabling their controls visibly. Disable World Runtime to use them again. Select World start/player settings explicitly; changing editor selection does not choose build settings for you.

Build & Run compiles and runs the current project. Build .NES ROM exports it. Failed builds must not run an earlier artifact. Run Original plays retained imported/opened bytes independently of current edits. Runtime capture retains its existing completed-frame/provenance behavior.

Read `WORLD_RUNTIME.md` before authoring a World build, or open `../examples/Scout_World_Traversal_1.7.nesforge.json` to inspect its editable traversal example. Open the older external Scout project to inspect the earlier single-room example; `SCOUT_REFERENCE.md` documents it. The example remains editable through ordinary tabs and does not become a production starter.

## Compatibility and evidence

Release identity is **1.7 — World Runtime**; project schema is **10**. Older supported projects migrate with World mode off when settings are absent. Current files require a compatible reader; do not lower their schema number. Unresolved authored IDs survive save/open for repair, but executable missing references fail build validation.

New World ROMs contain checked compressed authoring source excluding a previously imported ROM. Clean reopening restores that source and retains the newly opened ROM. JSON/ZIP remain the way to preserve the full project including any previous original bytes. See `FORMATS.md`.

All eight real-browser actions remain unverified. VM/ROM/emulator evidence and final candidate test counts are tracked separately in `BROWSER_QA.md` and `../CURRENT_BASELINE.md`.
