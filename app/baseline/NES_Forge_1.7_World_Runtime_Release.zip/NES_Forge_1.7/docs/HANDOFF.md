# Handoff location

The authoritative current **1.7 World Runtime** handoff is `../HANDOFF.md`. Read it with the root charter, architecture contract, decision log, roadmap, baseline evidence and test policy before continuing.

The original 1.6.7 handoff is archived in `history/1.6.7-current/root/HANDOFF.md`; the original 1.6.6 handoff is in `history/1.6.6/handoff.md`. Their capability, evidence and stop statements apply to those completed releases.

Complete the bounded 1.7 candidate and handoff. Do not begin 1.8 automatically.
