# Architecture status — 1.7

The 1.6.7 convergence is the retained foundation. Its exact report, measured 559/559 result and stage hashes are archived in `history/1.6.7-current/docs/CONVERGENCE_REPORT.md`. This current report describes the new World branch; final 1.7 verification passed 606/606 checks across 24 suites from a clean extraction, as recorded in `../CURRENT_BASELINE.md`.

## Active paths

| Operation | Owner and current route |
| --- | --- |
| Project capture/load/save/recovery | ProjectStore remains authoritative; schema 10 adds World settings to existing detached capture, validated preparation, commit and lifecycle guards |
| Explicit runtime selection | WorldConfig/WorldUI own saved World choices; old gameplay settings remain saved and their controls are disabled while World mode is active |
| Preflight/build/output | BuildGraph/RuntimeCompiler dispatch to the selected legacy backend or WorldCompiler; one final artifact is published |
| World dependency planning | WorldCompiler uses a detached snapshot, reachable destination worlds, direct metatile definitions and selected player animation assets |
| World execution | WorldEngine generates independent mapper-0 6502 traversal, per-quadrant collision, animation and screen/camera handling |
| World source/package/open | WorldRom allocates and checks layout 4/WG17 source; clean reopening uses the established replacement/undo boundary |
| Legacy source/ROM paths | Existing viewer/custom/single-room codecs and emitter remain; protected capture and append reconstruction retain ownership |
| Current identity/docs | ReleaseInfo and Documentation remain current owners; archived historical strings do not define active capabilities |
| Lookups/emulation/live editing | AssetRegistry remains lookup-oriented; EmulatorBridge remains thin; LiveLink remains inactive |

## Resource change

The old WR16/MT16 pipeline required world-used metatiles to appear in their source scene’s linked map. WorldCompiler now links directly from each used definition and its CHR/collision quadrants. It does not fabricate source-scene placements. The World branch follows its own reachable-world/player dependencies, while legacy Build Scene Set and golden outputs remain unchanged.

Resource descriptors expose ownership, sizes and bounded allocation. Derived screen/world/room/camera indices remain build-local; there is no new persistent runtime-ID store, incremental compiler or mapper-backed allocation. The new backend reports actual code/resource/source capacity before output.

## Retained boundaries

`S`, active scene mirrors, native editor tabs and existing undo architecture remain. Snapshot preparation still commits active edits before copying and is not claimed pure. New World planning is detached; retained legacy build helpers continue their documented synchronous global reads.

The emulator, provenance capture, Save As and CHR source guards remain required. The fixed-room emitter and five legacy golden ROMs retain byte/behavior protection. A separate World emitter avoids changing the old Player/Target contract. World attack animation does not execute target damage or generic contacts/events.

World ROM source intentionally excludes prior imported ROM bytes; JSON/ZIP preserve them. New source opening validates first and delegates replacement. Append Import explicitly refuses new World source instead of invoking legacy reconstruction on an incompatible envelope.

## Evidence limits

The required 1.7 full runner passed 606/606 checks across 24 suites against one unchanged candidate from a clean extraction, with zero failures/skips and exit status 0. The measured reports cover World planning, generated ROM execution, compatibility, source round trip, lifecycle and legacy preservation, including five byte-identical legacy ROMs. Final input/report identities and environment are recorded in `../CURRENT_BASELINE.md`. All eight browser acceptance actions and the new World controls remain unverified in `BROWSER_QA.md`.

Deliver the identified, reproducible 1.7 candidate and handoff, then stop. Audio Runtime, generic gameplay, new mappers, RE expansion and Live Edit require new authorization.
