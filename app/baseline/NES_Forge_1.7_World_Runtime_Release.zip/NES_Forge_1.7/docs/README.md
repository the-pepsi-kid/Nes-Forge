# Current documentation index — 1.7

| Document | Purpose |
| --- | --- |
| `CURRENT_GUIDE.md` | Project actions, build modes and save/reopen behavior |
| `WORLD_RUNTIME.md` | World authoring workflow, traversal/camera contract and limits |
| `FORMATS.md` | Schema 10, World layout 4/WG17 and preserved legacy formats |
| `CONVERGENCE_REPORT.md` | Active service ownership, new World boundaries and preserved adapters |
| `BROWSER_QA.md` | Eight unverified browser acceptance items |
| `SCOUT_REFERENCE.md` | Existing external single-room example values |
| `../PROJECT_CHARTER.md` | Current authority and scope |
| `../ARCHITECTURE_CONTRACT.md` | Lifecycle/build ownership and protected boundaries |
| `../DECISION_LOG.md` | Compatibility and bounded-runtime decisions |
| `../ROADMAP.md` | Current milestone and deferred work |
| `../CURRENT_BASELINE.md` | Frozen references and measured candidate evidence |
| `../TEST_POLICY.md` | Required tests, evidence and package reproduction |
| `../HANDOFF.md` | Authoritative current handoff |
| `history/1.6.7-current/` | Unmodified 1.6.7 documentation with archive hashes |
| `history/1.6.6/` | Earlier historical documents |

Current root documents and in-app Tech Docs define 1.7. Historical capability/stop statements and test counts apply only to their original releases. Final 1.7 evidence is recorded in `../CURRENT_BASELINE.md`: 606/606 checks across 24 suites from a clean extraction, with the final HTML and tested inputs identified by hashes. Browser acceptance remains unverified.
