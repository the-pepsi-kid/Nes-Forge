# Decision log

Historical 1.6.7 decisions D001–D007 are preserved verbatim in `docs/history/1.6.7-current/root/DECISION_LOG.md` and the frozen release. Their completed-milestone stop instructions are superseded only by the scope below. Blank startup, explicit factories, lifecycle ownership, protected boundaries and evidence discipline continue to apply.

## D008 — Proceed to bounded World Runtime

**Authority:** the user said “alright, let’s proceed” after 1.6.7 delivery. Implement the next World Runtime tranche through established service boundaries. Keep one existing-style authored player; general gameplay and audio remain later milestones. Do not add Scout-specific production behavior.

## D009 — Screen transitions

**Engineering decision:** use whole-screen camera transitions for 1.7. An optional camera preference question returned no answer. This is a bounded implementation choice, not an explicit user preference for screen stepping.

World coordinates use 16×16-pixel cells and a 16×15-cell viewport. Rooms/cameras must be screen aligned and non-overlapping within their own type. Camera records identify executable regions; smooth scrolling and dead-zone tracking are deferred. Record the exact behavior and limits in `docs/WORLD_RUNTIME.md`.

## D010 — Explicit start and traversal contract

World mode has separate saved start world, Spawn/Entrance and player source selections. Never infer them from active editor rows or first-found assets. Marker centers specify player feet at `(x×16+8,y×16+8)`. Entrance/exit traversal requires a new Up press while the feet occupy its cell; links specify both destination world and Spawn/Entrance marker. Validate clear body placement. Holding Up cannot bounce through reciprocal links. Start returns to the configured start. Screen crossings retain movement state; portal arrival resets transient player state. World mode executes attack animation without target damage.

## D011 — Schema 10 and distinct World ROM envelope

New World settings would be silently omitted by the 1.6.7 schema-9 serializer. Save schema 10 and require the actual older application to reject it. Retain supported legacy migrations, unresolved reference preservation and explicit downgrade rejection.

World ROMs use outer NFORGE15 layout 4 and WG17 v1 with deterministic LZSS-compressed authored source and CRC/length/placement validation. JSON source includes World settings and other authoring data, excluding prior imported ROM bytes to prevent recursive nesting. Clean reopening retains the newly opened ROM for original playback. Legacy layout-3 codecs and golden ROMs remain unchanged.

## D012 — Direct world resource linking

WorldCompiler follows start-world links and authored player dependencies independently of legacy Build Scene Set. World-used metatiles need no source-scene placement. Link their CHR/collision directly while preserving authoring IDs. Use deterministic build-local indices and allocation descriptors; stay on mapper 0. Format limits are upper bounds, not a promise that every authored world fits available PRG.

## D013 — Evidence and stop

The 1.7 runner must measure its own result and hash, followed by clean-package reproduction. The frozen 1.6.7 559/559 and 1.6.6 479/479 counts remain historical evidence. Browser acceptance is still unverified; the 1.7 attempt was rejected by Cloud Browser URL policy before application inspection (`checkpoints/1.7-browser-attempt.json`). Do not infer a browser pass from harness or emulator execution. Deliver 1.7 and stop; 1.8 is not authorized.
