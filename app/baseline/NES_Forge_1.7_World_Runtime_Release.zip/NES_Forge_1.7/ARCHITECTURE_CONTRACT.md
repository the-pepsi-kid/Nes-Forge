# Architecture contract — 1.7

## Ownership

| Boundary | Active responsibility | Limit |
| --- | --- | --- |
| ProjectStore | Schema 10, preparation/serialization, validation/commit, save/recovery lifecycle and load intents | Existing state `S`, undo engine and Save As transport remain |
| WorldConfig / WorldUI | Explicit saved World Runtime settings and ordinary WORLD sidebar controls | No hidden default world/player selection or wizard |
| AssetRegistry | Fresh authoring lookups and reference diagnostics | No persistent runtime IDs, mutation or competing state store |
| BuildGraph / RuntimeCompiler | Select the backend, preflight, compile and publish one successful artifact | Legacy branches preserve byte output and phase order |
| WorldCompiler | Detached reachable-world/asset closure, geometry validation, screen/resource plan and world compilation orchestration | One player, Empty/Solid collision, screen transitions, mapper 0 |
| WorldEngine | Dedicated generated 6502 traversal/animation runtime | Existing single-room emitter and emulator stay unchanged |
| WorldRom | Layout 4, WG17 compression/checksums/allocation, validated clean reopening | Legacy codecs and append reconstruction remain separate |
| ReleaseInfo / Documentation | Current release identity, capabilities and Tech Docs | Historical docs are evidence, not active instructions |
| EmulatorBridge / LiveLink | Existing emulator façade / inactive capability contract | No emulator rewrite, hot reload or background synchronization |

WorldConfig is a top-level `worldRuntime` object. It contains `enabled`, `worldId`, `spawnId`, `playerSceneId`, `playerId`, and the existing six movement/body parameters. Existing `gameplay` settings remain separate and preserved. When World mode is enabled its backend is authoritative and the old gameplay controls are visibly disabled; turning it off restores their saved choices.

## World build

The World branch prepares one detached project snapshot, follows links from its selected start world, validates executable geometry, links actual world metatile and selected-player animation dependencies, packs screens, generates code, allocates code/source data, writes the checked source record and emits one artifact. The legacy Build Scene Set does not define the World dependency closure.

World-only metatiles must link directly from their source definitions, including all four CHR tiles and collision quadrants. Do not insert hidden scene placements or remove a guard while dropping required graphics. Build-local resource indices are derived; authored identities do not become ROM addresses. Resource descriptors identify ownership, size, alignment and allocation without implying a new mapper allocator.

NROM output is 32 KB PRG plus 8 KB CHR, with separate 256-tile background/sprite banks. The format profile allows at most 32 reachable worlds and 64 reachable screens; actual code, uncompressed screen resources and compressed source usually impose a lower capacity. Failure reports the measured limit and publishes no stale artifact.

`docs/WORLD_RUNTIME.md` defines screen-aligned room/camera geometry, markers, collision and camera behavior. `docs/FORMATS.md` defines schema 10 and the distinct layout-4/WG17 record.

## Preserved legacy build

Viewer/custom and single-room keep their existing pipeline: prepare; select/remap; atlas/metatile/world metadata; MS16 asset linking; code occupancy; allocation; scene packing; final CHR; optional existing gameplay compiler; artifact. Final CHR follows linking, allocation follows code/vector discovery, and the single-room path never downloads an intermediate viewer ROM.

Preserve the five golden ROMs without masks or regenerated expectations. Legacy targets keep mapper 0, 16/32 KB PRG, 8 KB CHR, seven packed scenes, `$D000`/`$0600` scene layout, existing metadata reservations and `$B800` GP16 configuration. World Runtime is a separate branch, not a changed legacy emitter.

## Lifecycle and compatibility

Decode/validate before mutation. Ordinary full-project opening clears history; New Project and Open Forge ROM remain undoable replacements; ordinary history replay retains its existing policy. World ROM opening uses the established replacement boundary after checking the new format. Append Import rejects this new source format with Open Forge ROM guidance and otherwise delegates unchanged.

Schema 10 prevents older editors from silently dropping World settings. Test rejection against the actual frozen 1.6.7 application. Keep schema-9 unresolved-reference preservation and the actual 1.6.6 data-loss characterization. Unsupported downgrade, malformed/future schemas and recognized invalid ROMs reject atomically.

Retain recovery/save generation guards, active-scene preparation, detached snapshots, Build & Run versus Run Original, protected source hashes, and the inactive LiveLink contract. Stop after the verified 1.7 candidate.
