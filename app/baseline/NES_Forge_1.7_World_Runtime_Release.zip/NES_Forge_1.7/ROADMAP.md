# NES Forge roadmap

| Milestone | Scope | Status |
| --- | --- | --- |
| 1.6.6 — Visual Workspace | Original editor/capture and single-room Player/Target reference | Frozen historical baseline |
| 1.6.7 — Architecture Convergence | ProjectStore, BuildGraph/RuntimeCompiler, blank startup, preservation semantics and current documentation | Delivered frozen baseline |
| 1.7 — World Runtime | Direct world resource linking; one authored sideview player; Empty/Solid collision; screen transitions; explicit start/entrance links; checked world ROM reopening | Implemented; clean release gate passed; browser acceptance unverified |
| 1.8 — Audio Runtime / Studio | Existing tracker music/SFX compilation and sound-event connection; later MIDI/MusicXML import | Deferred; new authorization required |
| 1.9 — General Gameplay Systems | Generic actors, hazards, ladders, moving platforms, pickups, triggers, dialogue and projectiles | Deferred; new authorization required |
| 2.0 — Runtime/Linker + Live Play foundation | Mapper-backed allocation, stable runtime asset IDs, incremental compilation and editor/emulator synchronization | Deferred; new authorization required |

The 1.7 camera implementation changes screens; smooth scrolling is not included. World resources have explicit dependencies and allocation records, but output still uses mapper 0. World attack animations do not implement a damage system. General actor, audio and event data remain authored/preserved where not executed.

Existing supported-ROM playback/capture does not imply general reconstruction of game logic. LiveLink remains inactive. Stop after the 1.7 candidate, reproducible package and handoff; this roadmap is not standing authorization for the next milestone.
