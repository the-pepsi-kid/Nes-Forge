# Test and release policy — 1.7

## Evidence rules

Every published result must identify the actual candidate HTML hash, exact commands/environment, suite and case counts, failures/skips and exit status. A skipped required suite fails the release gate. Never combine unrelated runs or promote smoke checks to a full acceptance claim.

Frozen results belong to their artifacts: 1.6.6 measured 479/479 across 17 suites; 1.6.7 measured 559/559 across 23 suites. The 1.7 runner measures its own total. Keep original releases, tests, fixtures and five golden ROMs; never regenerate golden bytes or protected hashes to excuse a regression.

Narrow candidate adaptations may update release/schema expectations and explicitly changed World behavior. Keep prior behavioral assertions and historical reproduction. Tests must not inject missing production functions, substitute an older HTML or rebuild a missing artifact silently.

## Required coverage

| Area | Required evidence |
| --- | --- |
| Source and preservation | Deterministic complete bundle; missing/duplicate source rejection; protected emulator/capture/Save As/CHR spans; five legacy whole-ROM goldens |
| Project lifecycle | Schema 10 output; actual 1.6.7 rejection; legacy migrations and actual 1.6.6 data-loss characterization; World settings/reference persistence; atomic malformed-input rejection; save/recovery races and history policies |
| Native controls | Explicit World selections without inferred defaults; normal sidebar and mode ownership; invalid settings leave saved data intact; undo/reopen refresh correctly |
| World planner | Reachable-world closure; world-only metatiles and CHR retention; deterministic resource order; screen/room/camera/marker validation; per-quadrant Empty/Solid collision and source palette handling |
| Generated ROM | Actual bundled-emulator movement, jumping, screen crossings, collisions, animation, marker arrival, held-Up suppression and Start reset; stable RAM/OAM/pixel evidence where asserted |
| Source envelope | Layout 4 / WG17 lengths, checksums, bounds and unsupported versions; authoring round trip; original-ROM exclusion; atomic clean reopen and rejection through append Import |
| Dispatch and limits | BuildGraph/RuntimeCompiler own all active modes; final capacity checks; exactly one published artifact; failed build never runs stale output; legacy backend phases unchanged |
| Package | Full required run on one unchanged candidate; fresh extraction with all inputs; source check and full runner reproduce the measured result |

Complete relevant checks before broadening the implementation. Resolve concrete failures; avoid accumulating optional tests after the required risks and gates are satisfied.

## Reproduction

```sh
python3 tools/bundle.py --check
node tests/run_all.cjs
```

Node.js 20+ and Python 3 are verification tools; standalone editor use requires neither. Include runnable suites, fixtures, the suite manifest, per-suite reports/logs and exact measured environment in the package. Final extraction verification must use the delivered inputs, not an unrelated development directory.

## Browser evidence

The complete-app VM verifies program/handler behavior with a mock DOM. Whole-ROM comparisons verify bytes. Bundled-emulator execution verifies the generated runtime under that emulator. None proves browser layout, native pickers, real storage timing or independent NES hardware correctness.

All eight browser actions in `docs/BROWSER_QA.md` remain unverified. The current blocked 1.7 attempt is recorded in `checkpoints/1.7-browser-attempt.json`; preserve the older record as historical. Record a pass only after actual permitted interaction. Never infer acceptance from source checks or evade the browser security boundary.

Deliver the verified 1.7 candidate and handoff, then stop. Later milestones require new authorization.
