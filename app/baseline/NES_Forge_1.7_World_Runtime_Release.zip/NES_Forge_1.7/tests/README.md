# Reproducible tests — NES Forge 1.7

Run from a clean release extraction with Node.js 20+ and Python 3:

```sh
python3 tools/bundle.py --check
node tests/run_all.cjs
```

No package installation, network access or proprietary ROM is required. The standalone editor itself requires neither tool.

The strict runner tests `mainline/NES_Forge_1.7_World_Runtime.html`, requires all 24 suites, and writes fresh per-suite reports/logs plus `test-results/candidate/Summary.json`. It identifies the unchanged HTML hash and verifies input hashes throughout the run. Missing inputs, skipped cases, filters, source injection and older-HTML fallbacks fail the release gate. The measured final result is recorded in `../CURRENT_BASELINE.md`.

## Retained coverage

The 17 original behavioral suites retain world codecs, editor/history behavior, metasprites, animation/entity editing, collision, single-room compilation, actual bundled-emulator gameplay, project replacement and native authoring workflows. Six architecture suites retain ProjectStore, lifecycle races, complete-ROM golden comparisons, service routing, recognized ROM-format rejection and deterministic source bundling.

Narrow 1.7 adaptations cover schema 10, release identity, the additional World backend and standalone candidate paths. Exact originals of changed 1.6.7 tests are in `historical167/`; its README explains each adaptation. The complete frozen 1.6.7 ZIP under `../baseline/` remains independently runnable with its original 559/559 result. The frozen 1.6.6 archive retains its original 479/479 result. Historical totals are not the 1.7 total.

The five immutable complete-ROM oracles in `fixtures/golden167/` are unchanged. Expected bytes and protected-source hashes must never be updated to conceal regressions. `version-expectations.cjs` centralizes intentional schema/release differences without discarding authored values.

## World Runtime coverage

`world-runtime170.cjs` loads the complete candidate and builds its ordinary external fixture from `world-fixtures170.cjs`. It verifies configuration/history and movement-body preview, dependency closure for world-only metatiles, deterministic linking, exact CHR output, camera selection, diagnostics and resource failures, single artifact publication, source-record round trips and corruption rejection, and actual frozen-editor rejection.

Generated 6502 execution verifies spawn/grounding, both-axis screen crossings, neighbor collision, jumping, exact OAM facing, attack timing, linked-marker activation and held-Up suppression, restart, locked-camera display/clipping, safe PPU writes, balanced stack/registers and bounded main/NMI work. Maximum-body/physics/24-piece corner cases are retained because ordinary central-screen checks do not cover their timing risk. These tests execute ROM instructions; they do not substitute a JavaScript physics model.

The external editable example can be regenerated through the supplied complete application:

```sh
node tools/build_world_example.cjs
```

Run example generation before the final release gate: examples are hashed test inputs and must remain unchanged during that gate.

## Evidence limits

The VM harness has a mock DOM and controlled storage/timers. Bundled-emulator execution is separate from real browser interaction and independent NES hardware verification. All eight legacy browser actions and the new WORLD controls remain unverified because the permitted standalone-file navigation was rejected. See `../docs/BROWSER_QA.md` and `../checkpoints/1.7-browser-attempt.json`.

Historical extraction/convergence checkpoints under `../checkpoints/` belong to 1.6.7 unless explicitly labeled 1.7. Current clean-extraction evidence belongs under `../checkpoints/1.7-clean-extraction/`.
