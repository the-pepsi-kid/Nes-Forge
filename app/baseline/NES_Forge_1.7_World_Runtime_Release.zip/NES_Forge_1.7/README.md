# NES Forge 1.7 — World Runtime

Open `mainline/NES_Forge_1.7_World_Runtime.html` in a browser. The editor remains a standalone HTML application; no server, installation or development tools are required to use it.

1.7 adds a bounded sideview World Runtime: one authored player moves and jumps through metatile worlds, crosses screen boundaries and uses linked entrances/exits. The camera changes by whole screens. Viewer/custom assembly and the existing single-room Player/Target modes retain their separate behavior.

## Author and play

Fresh startup is a blank viewer scene with World Runtime off. New Project creates the established blank single-room project and is undoable. Recovery uses the existing Restore/Dismiss banner. No example is loaded automatically.

Use CHR SHEET, METATILES and WORLD to draw terrain; METASPRITES, ANIM and ENTITY STUDIO to author and bind a Player. In WORLD, enable World Runtime and explicitly select its start world, Spawn/Entrance marker, player source scene and Player entity. World mode follows those saved dependencies independently of the legacy Build Scene Set. See `docs/WORLD_RUNTIME.md` for the complete workflow and restrictions.

**Build & Run** builds the current project. Left/Right move, **Z** jumps, **X** plays the attack animation, **Up** enters a linked entrance/exit while occupying its cell, and **Enter** restarts. World mode has no target damage, general actors, hazards or music runtime. Its existing player animations provide the traversal presentation; contact boxes and events remain authored data.

To inspect an ordinary editable World example, use Open Project and select `examples/Scout_World_Traversal_1.7.nesforge.json`. Its matching `.nes` is supplied for playback/reopening. The original `Scout_Authored_in_Editor_1.6.6.nesforge.json` remains the separate single-room example.

## Save and reopen

Save and Save Project As/Export retain project authoring data. New project saves use **schema 10** because older editors cannot preserve the new World Runtime settings. The actual 1.6.7 editor must reject these files. Supported older projects open with World Runtime off unless they explicitly supply valid settings. Downgrade is unsupported; keep older backups instead of changing schema numbers.

World builds use mapper 0, 32 KB PRG and 8 KB CHR with a new Forge layout-4/WG17 source record. **Open Forge ROM** validates and restores that authored project, retaining the newly opened ROM as the original for **Run Original**. The source record excludes previously imported ROM bytes to prevent recursive growth. Use project JSON/ZIP to retain every backup, including a previous imported original. **Import ROM** rejects this new format with guidance to use Open Forge ROM. Existing layout-3 import/capture paths remain separate. See `docs/FORMATS.md`.

## Verify and develop

With Node.js 20+ and Python 3, run from this directory:

```sh
python3 tools/bundle.py --check
node tests/run_all.cjs
```

The clean-extraction release gate passed **606/606 checks across 24 suites**, with zero failures or skips and exit status 0. This includes all 559 retained checks and 47 World Runtime checks. `CURRENT_BASELINE.md` records the final HTML hash, exact environment and reproduction evidence; `test-results/candidate/Summary.json` contains the measured reports and input hashes. Real-browser acceptance remains unverified for all eight actions and the new World controls listed in `docs/BROWSER_QA.md`.

Authoritative sources are listed in `source-manifest.json`; `python3 tools/bundle.py` produces the standalone HTML. Read `PROJECT_CHARTER.md`, `ARCHITECTURE_CONTRACT.md`, `DECISION_LOG.md`, `ROADMAP.md`, `CURRENT_BASELINE.md`, `TEST_POLICY.md` and `HANDOFF.md`. Original releases and documentation are retained as historical evidence. Scope ends with the tested 1.7 candidate and handoff; 1.8 is not authorized.
