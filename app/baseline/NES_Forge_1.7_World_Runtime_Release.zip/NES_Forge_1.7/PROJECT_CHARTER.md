# NES Forge project charter

NES Forge is a visual NES authoring environment with optional assembly and existing ROM inspection/capture tools. Ordinary editor controls remain the primary workflow. The distributed application remains one standalone HTML with reproducible source, tools, tests and editable external examples.

## Authorized milestone

The user’s “alright, let’s proceed” authorizes continuation into **1.7 — World Runtime** after the delivered 1.6.7 Architecture Convergence candidate. This supersedes the historical stop-before-1.7 language. It does not authorize every later roadmap feature.

This tranche executes World/Room/Spawn/Entrance/Camera/Metatile data through a dedicated NROM backend: one authored sideview Player, existing movement/jump/animation conventions, Empty/Solid collision, whole-screen camera transitions and explicit marker links. Resource linking follows world and player dependencies, retaining metatiles used only in WORLD. Project schema 10 and a distinct checked World ROM source record preserve the new choices on save/reopen.

Whole-screen transitions are the documented engineering default for this bounded tranche. An optional camera-choice question received no answer; do not describe the user as explicitly choosing this camera implementation.

## Boundaries

- Preserve viewer/custom and single-room behavior, five pinned reference ROMs, and their existing formats.
- Keep ProjectStore and BuildGraph/RuntimeCompiler authoritative. Keep AssetRegistry lookup-oriented, EmulatorBridge thin and LiveLink inactive.
- Preserve protected emulator, capture, Save As and CHR code; do not rewrite undo, editor rendering or legacy append reconstruction for tidiness.
- Keep blank viewer startup, the existing recovery banner and distinct undoable blank single-room New Project behavior. World mode starts off.
- Validate before replacing project/history/runtime/save identity. Preserve unresolved authoring references for repair and reject unsupported executable inputs clearly.
- Do not add smooth scrolling, a mapper target, generic enemies or interactions, target damage in World mode, Audio Runtime, generalized reverse engineering or Live Edit.

## Completion

Deliver one identified 1.7 candidate with reproducible source, passing required tests, clean-package reproduction, documented limitations and handoff. Separate measured automated evidence from unverified browser acceptance. Stop after this candidate; beginning 1.8 or broadening gameplay requires a new user instruction.
