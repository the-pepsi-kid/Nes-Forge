# NES Forge 1.7 handoff

## Current scope

The user authorized proceeding after 1.6.7 into **1.7 — World Runtime**. The current tranche is one authored sideview player, Empty/Solid metatile collision, screen transitions and explicit start/entrance links on mapper 0. Whole-screen camera behavior is an engineering default, not an explicit user camera preference. No Audio Runtime, generic gameplay, new mapper, RE engine or Live Edit is authorized.

Read the root charter, architecture contract, decision log, roadmap, baseline evidence and test policy. The original 1.6.7 governance set is preserved under `docs/history/1.6.7-current/`; its old stop-before-1.7 instructions are historical.

## Entry points

- Application: `mainline/NES_Forge_1.7_World_Runtime.html`.
- Source: `source-manifest.json` and `src/`; bundle with `python3 tools/bundle.py`.
- Verify: `python3 tools/bundle.py --check` and `node tests/run_all.cjs`.
- World workflow/limits: `docs/WORLD_RUNTIME.md`; formats: `docs/FORMATS.md`; editable example: `examples/Scout_World_Traversal_1.7.nesforge.json` and matching `.nes`.
- World implementation: `src/world/world-config.js`, `world-ui.js`, `world-compiler.js`, `world-engine.js`, `world-rom.js`.
- Lifecycle and dispatch: `src/services/project-store.js`, `build-services.js`; current identity/docs remain service-owned.

## Preserve these decisions

1. Project schema 10 preserves separate `worldRuntime` settings. The actual frozen 1.6.7 reader must reject new projects atomically. Do not lower schema numbers or offer silent downgrade.
2. Startup remains blank viewer mode; New Project remains an undoable blank single-room factory. World mode starts disabled and requires explicit world/start/player selection.
3. World mode follows reachable worlds and selected animation/CHR dependencies independently of legacy Build Scene Set. World-only metatiles link directly; authoring IDs remain stable.
4. Rooms/cameras are screen-aligned executable regions. Markers use cell-center feet; Up requires a new press and a fully specified Spawn/Entrance destination. Arrival/reset and collision rules are documented.
5. World ROMs use layout 4 / WG17 v1 checked compressed source. Reopening validates first, uses the existing replacement/undo boundary and retains the opened ROM for Run Original. Prior imported bytes are excluded from embedded source. Append Import refuses this new format explicitly.
6. Preserve legacy viewer/custom/single-room goldens, layout-3 codecs and fixed-room emitter. World attacks animate without target damage. Protected emulator/capture/Save As/CHR, undo/rendering ownership and inactive LiveLink remain intact.
7. Format maxima do not promise NROM capacity: code, screen data, graphics and compressed authoring are separately bounded and must fail clearly before publication.

## Evidence and delivery status

The frozen 1.7 HTML is `abcf22812bf027001d8a25ac6f64295755d4f1a2ddf281ac3ce0760a3039ed3f` (921,984 bytes). The clean-extraction required runner passed **606/606 across 24 suites**, with 0 failures, 0 skips and exit status 0. `CURRENT_BASELINE.md`, `test-results/candidate/Summary.json` and `checkpoints/1.7-clean-extraction/Reproduction.json` record exact environment, reports and input identities. The five legacy whole-ROM outputs remain byte-identical; the separate World suite passed all 47 cases.

Real-browser acceptance is unverified for blank startup, recovery banner, Save, Save As, project opening, Build & Run, Run Original and runtime capture. The 1.7 URL-policy rejection is recorded in `checkpoints/1.7-browser-attempt.json`; it occurred before UI inspection on a mutable candidate. World controls are also unverified. The earlier blocked attempt remains historical evidence. Separate source/VM/golden/emulator checks from browser acceptance.

The required clean-extraction run is complete. Deliver the standalone HTML and release archive containing the reproducible sources, editable example, measured reports and this handoff, then stop. **Do not begin 1.8 automatically.**
