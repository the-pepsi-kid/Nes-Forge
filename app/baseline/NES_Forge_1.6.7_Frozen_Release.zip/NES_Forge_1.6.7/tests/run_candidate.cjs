#!/usr/bin/env node
'use strict';
// Strict release gate: one unchanged standalone candidate, all retained suites,
// fresh reports, no filters, module repair, source fallback, or inferred passes.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const fileHash=file=>hash(fs.readFileSync(file));
const html=path.resolve(process.argv[2]||path.join(root,'mainline/NES_Forge_1.6.7_Architecture_Convergence.html'));
const output=path.resolve(process.argv[3]||path.join(root,'test-results/candidate'));
const summaryPath=path.join(output,'Summary.json');
const expectedBaseline=['world-codec','regression','metasprites','composer-interactions','model164','frame-editor164','entity-studio164','persistence164','compiler165','ui165','persistence165','gameplay165','engine165','project166','placement166','native-ui166','native-authoring166'];
const additional=[['project-store167','tests/project-store167.cjs'],['lifecycle167','tests/lifecycle167.cjs'],['golden-parity167','tests/golden-parity167.cjs'],['services167','tests/services167.cjs'],['rom-compat167','tests/rom-compat167.cjs'],['convergence-source167','tests/convergence-source167.cjs']];
function requireFile(file){assert.ok(fs.existsSync(file)&&fs.statSync(file).isFile(),'Required package file is missing: '+path.relative(root,file));}
function discoverBaselineJobs(){
  const runner=path.join(__dirname,'run_frozen.cjs');requireFile(runner);
  const match=fs.readFileSync(runner,'utf8').match(/const jobs=\[([\s\S]*?)\n\];/);
  assert.ok(match,'Retained runner must contain its explicit baseline jobs manifest');
  const jobs=[...match[1].matchAll(/\[\s*'([^']+)'\s*,\s*'([^']+)'\s*\]/g)].map(m=>[m[1],m[2]]);
  assert.deepEqual(jobs.map(j=>j[0]),expectedBaseline,'All 17 retained baseline suites must remain present and ordered');return jobs;
}
function walk(dir){
  requireDirectory(dir);const result=[];for(const item of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const file=path.join(dir,item.name);if(item.isDirectory())result.push(...walk(file));else if(item.isFile())result.push(file);}return result;
}
function requireDirectory(dir){assert.ok(fs.existsSync(dir)&&fs.statSync(dir).isDirectory(),'Required package directory is missing: '+path.relative(root,dir));}
function inputProvenance(jobs){
  const files=new Set([__filename,path.join(__dirname,'run_all.cjs'),path.join(__dirname,'run_frozen.cjs'),path.join(__dirname,'harness.cjs'),path.join(__dirname,'fixtures.cjs'),path.join(__dirname,'composer-cases.cjs'),path.join(__dirname,'version-expectations.cjs'),path.join(__dirname,'preserved-source.json'),path.join(root,'tools/capture_goldens.cjs'),...jobs.map(j=>path.join(root,j[1]))]);
  for(const dir of ['baseline','examples','tests/fixtures'])for(const file of walk(path.join(root,dir)))files.add(file);
  // The lifecycle suite uses an independent deterministic browser-storage harness.
  for(const file of fs.readdirSync(__dirname))if(/harness.*\.cjs$/.test(file))files.add(path.join(__dirname,file));
  return [...files].sort().map(file=>{requireFile(file);return {path:path.relative(root,file),bytes:fs.statSync(file).size,sha256:fileHash(file)};});
}
function unchangedInputs(initial){for(const input of initial)assert.equal(fileHash(path.join(root,input.path)),input.sha256,'Test input changed during the run: '+input.path);}
function noSkipped(value,where){
  if(!value||typeof value!=='object')return;
  for(const [key,item]of Object.entries(value)){
    if(/^(?:skip|skipped|todo|pending|filtered|filterApplied)$/i.test(key))assert.ok(item===false||item===0||item===null||item==='',where+' reports '+key);
    if(key==='status'&&typeof item==='string')assert.doesNotMatch(item,/skip|todo|pending|filtered/i,where+' status');
  }
}
function validateReport(name,data,initialHash){
  assert.ok(data&&typeof data==='object'&&!Array.isArray(data),name+' report must be an object');
  assert.equal(data.appendedModule,undefined,name+' must not repair the app by injecting a missing module');
  assert.equal(data.moduleSha256,undefined,name+' must test the standalone candidate alone');
  noSkipped(data,name);
  const cases=Array.isArray(data.results)?data.results:Array.isArray(data.tests)?data.tests:null;
  assert.ok(cases&&cases.length>0,name+' has no explicit measured cases');
  assert.ok(Number.isInteger(data.total)&&data.total>0,name+' needs an explicit positive measured total');
  assert.ok(Number.isInteger(data.passed)&&data.passed>=0,name+' needs an explicit passed count');
  assert.equal(data.total,cases.length,name+' total must equal its case records');
  for(const [i,result]of cases.entries()){assert.ok(result&&typeof result.name==='string'&&result.name.trim(),name+' case '+i+' needs a name');noSkipped(result,name+'/'+result.name);assert.equal(result.passed,true,name+'/'+result.name+' did not pass');}
  const measured=cases.filter(c=>c.passed===true).length;
  assert.equal(data.passed,measured,name+' claimed passed count differs from case records');assert.equal(data.passed,data.total,name+' has failures');
  if(data.failed!==undefined){assert.ok(Number.isInteger(data.failed),name+' failed must be an integer');assert.equal(data.failed,0,name+' reports failures');}
  for(const key of ['sha256','htmlSha256'])if(data[key]!==undefined)assert.equal(data[key],initialHash,name+' tested a different HTML hash');
  for(const key of ['html','source'])if(data[key]!==undefined)assert.equal(path.basename(data[key]),path.basename(html),name+' reports a different candidate');
  return {passed:measured,total:cases.length,failed:0};
}
function main(){
  fs.mkdirSync(output,{recursive:true});
  // Clear owned reports even if required inputs or suite discovery later fail.
  for(const file of [summaryPath,...[...expectedBaseline,...additional.map(j=>j[0])].flatMap(name=>[path.join(output,name+'.json'),path.join(output,name+'.log')])])if(fs.existsSync(file))fs.unlinkSync(file);
  assert.ok(!process.env.FORGE_TEST_FILTER,'FORGE_TEST_FILTER is not permitted by the complete release gate');
  assert.ok(process.argv.length<=4,'Usage: node tests/run_candidate.cjs [candidate.html] [report-directory]');
  requireFile(html);const jobs=[...discoverBaselineJobs(),...additional];
  for(const [,script]of jobs)requireFile(path.join(root,script));
  requireFile(path.join(root,'tests/fixtures/golden167/manifest.json'));requireFile(path.join(root,'baseline/NES_Forge_1.6.6_Visual_Workspace.html'));
  const initialHash=fileHash(html),inputs=inputProvenance(jobs),startedAt=new Date().toISOString(),suites=[];
  const runtime={node:process.version,platform:process.platform,architecture:process.arch};
  let failedSuite=null;
  try{
    for(const [name,script]of jobs){
      failedSuite=name;assert.equal(fileHash(html),initialHash,'The release HTML changed between suites');unchangedInputs(inputs);
      const report=path.join(output,name+'.json'),log=path.join(output,name+'.log'),start=Date.now();
      const result=cp.spawnSync(process.execPath,[path.join(root,script),html,report],{cwd:root,env:{...process.env,FORGE_TEST_REPORT:report,FORGE_TEST_FILTER:''},encoding:'utf8',timeout:name==='native-authoring166'?360000:180000,maxBuffer:8*1024*1024});
      fs.writeFileSync(log,(result.stdout||'')+(result.stderr||''));
      if(result.error)throw Error(name+' process error: '+result.error.message);
      assert.equal(result.signal,null,name+' was terminated by '+result.signal);assert.equal(result.status,0,name+' exited '+result.status+'; see '+path.relative(root,log));
      if(name==='world-codec')fs.writeFileSync(report,result.stdout);
      requireFile(report);const data=JSON.parse(fs.readFileSync(report,'utf8')),counts=validateReport(name,data,initialHash);
      assert.equal(fileHash(html),initialHash,name+' changed the release HTML');unchangedInputs(inputs);
      suites.push({name,script,...counts,milliseconds:Date.now()-start,scriptSha256:fileHash(path.join(root,script)),report:path.relative(root,report),reportSha256:fileHash(report),log:path.relative(root,log)});
      process.stdout.write('PASS '+name+': '+counts.passed+'/'+counts.total+'\n');
    }
    failedSuite=null;assert.equal(suites.length,expectedBaseline.length+additional.length,'Every required suite must complete');
  }catch(error){
    fs.writeFileSync(summaryPath,JSON.stringify({release:'1.6.7',status:'failed',html:path.relative(root,html),sha256:initialHash,startedAt,finishedAt:new Date().toISOString(),runtime,failedSuite,error:error.message,completedSuites:suites,requiredSuites:jobs.map(j=>j[0]),provenance:inputs},null,2)+'\n');throw error;
  }
  const summary={release:'1.6.7',status:'passed',html:path.relative(root,html),sha256:initialHash,unchangedCandidate:true,startedAt,finishedAt:new Date().toISOString(),runtime,
    passed:suites.reduce((n,s)=>n+s.passed,0),failed:0,total:suites.reduce((n,s)=>n+s.total,0),suiteCount:suites.length,suites,
    policy:'All 17 retained baseline suites plus 6 architecture suites, no filters or skipped cases; totals measured from fresh explicit case records.',
    provenance:inputs,browserAcceptance:'Separate evidence is required. This automated VM runner makes no real-browser, native picker, or browser rendering claim.'};
  fs.writeFileSync(summaryPath,JSON.stringify(summary,null,2)+'\n');process.stdout.write(summary.passed+'/'+summary.total+' automated cases passed against unchanged '+initialHash+'\n');
}
module.exports={expectedBaseline,additional,discoverBaselineJobs,validateReport,jobs:()=>[...discoverBaselineJobs(),...additional]};
if(require.main===module)try{main();}catch(error){
  // A missing file, filtered invocation, or malformed manifest cannot leave an
  // older successful Summary.json in place to masquerade as this run's result.
  if(!fs.existsSync(summaryPath)){fs.mkdirSync(output,{recursive:true});fs.writeFileSync(summaryPath,JSON.stringify({release:'1.6.7',status:'failed',html:path.relative(root,html),error:error.message,finishedAt:new Date().toISOString()},null,2)+'\n');}
  console.error('FAIL release gate: '+error.message);process.exitCode=1;
}
