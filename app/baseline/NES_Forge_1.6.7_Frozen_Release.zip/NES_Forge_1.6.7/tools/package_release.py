"""Package only the reproducibly bundled, fully measured 1.6.7 candidate."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path)
parser.add_argument('--stage', action='store_true', help='Create an unmeasured input archive for clean-extraction testing; requires an explicit staging output name.')
args = parser.parse_args()
if args.stage:
    assert args.output and 'staging' in args.output.name.lower(), 'Staging requires an explicit staging archive name'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python3', str(root/'tools/bundle.py'), '--check'], cwd=root, check=True)
manifest = json.loads((root/'source-manifest.json').read_text())
html = root/manifest['output']
summary = None
if not args.stage:
    summary = json.loads((root/'test-results/candidate/Summary.json').read_text())
    assert summary['status'] == 'passed' and summary['failed'] == 0
    assert summary['passed'] == summary['total'] > 0 and summary['suiteCount'] == 23
    assert digest(html) == summary['sha256'], 'HTML differs from the tested candidate'
    for item in summary['provenance']:
        assert digest(root/item['path']) == item['sha256'], 'Changed test input: '+item['path']
    for suite in summary['suites']:
        assert suite['passed'] == suite['total'] and suite['failed'] == 0
        assert digest(root/suite['report']) == suite['reportSha256'], 'Changed measured report'

names = ['README.md', 'PROJECT_CHARTER.md', 'ARCHITECTURE_CONTRACT.md', 'DECISION_LOG.md',
         'ROADMAP.md', 'CURRENT_BASELINE.md', 'TEST_POLICY.md', 'HANDOFF.md',
         'package.json', 'source-manifest.json', 'build-inputs.json', manifest['output']]
files = {root/name for name in names}
directories = ['src', 'tools', 'tests', 'stabilization', 'baseline', 'examples', 'docs', 'checkpoints']
if not args.stage:
    directories.append('test-results/candidate')
for name in directories:
    folder = root/name
    assert folder.is_dir(), 'Required directory missing: '+name
    for file in folder.rglob('*'):
        if file.is_file() and '__pycache__' not in file.parts and file.suffix not in {'.pyc', '.rgba'}:
            files.add(file)
for file in files:
    assert file.is_file() and file.resolve().is_relative_to(root), 'Invalid package input: '+str(file)
files = sorted(files, key=lambda p: p.relative_to(root).as_posix())
checksums = root/'SHA256SUMS.txt'
checksums.write_text(''.join(digest(p)+'  '+p.relative_to(root).as_posix()+'\n' for p in files))
target = (args.output or root.parent/'NES_Forge_1.6.7_Architecture_Convergence_Release.zip').resolve()
assert not target.is_relative_to(root), 'Write the archive outside its source tree'
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for file in files+[checksums]:
        entry = zipfile.ZipInfo('NES_Forge_1.6.7/'+file.relative_to(root).as_posix(), (2026, 9, 14, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        z.writestr(entry, file.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for file in files:
        assert hashlib.sha256(z.read('NES_Forge_1.6.7/'+file.relative_to(root).as_posix())).hexdigest() == digest(file)
print(json.dumps({'archive': str(target), 'archiveSha256': digest(target), 'files': len(files)+1,
                  'htmlSha256': digest(html), 'stagingOnly': args.stage,
                  'passed': summary['passed'] if summary else None, 'total': summary['total'] if summary else None}, indent=2))
