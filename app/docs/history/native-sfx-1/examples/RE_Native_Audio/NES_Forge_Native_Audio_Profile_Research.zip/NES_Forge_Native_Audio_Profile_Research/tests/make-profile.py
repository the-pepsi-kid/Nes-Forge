"""Reproduce the instruction-structure profile from the pinned licensed source build.
This generator is an offline development tool; the JS decoder never needs its ROM.
"""
import json,re,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
checkpoint=Path(sys.argv[1]) if len(sys.argv)>1 else root.parent/'native-audio-discovery-2026-10-08'
rom=(checkpoint/'HonkeyPong-reproduced.nes').read_bytes()
assert hashlib.sha256(rom).hexdigest()=='cce7bf2f71eb9e63de0dba15098679dde06a1da9d7553f2319aa60ea57a1193b'
s={b:int(a,16) for a,b in re.findall(r'^\$([A-F0-9]+)\s*\|\s*(\S+)\s*\|',(checkpoint/'HonkeyPong-reproduced.map').read_text(),re.M)}
# Official NMOS 6502 opcodes only. Operand classification is used for structural relocation.
rows='''BRK:i ORA:ix - - - ORA:z ASL:z - PHP:i ORA:m ASL:a - - ORA:b ASL:b -
BPL:r ORA:iy - - - ORA:zx ASL:zx - CLC:i ORA:by - - - ORA:bx ASL:bx -
JSR:b AND:ix - - BIT:z AND:z ROL:z - PLP:i AND:m ROL:a - BIT:b AND:b ROL:b -
BMI:r AND:iy - - - AND:zx ROL:zx - SEC:i AND:by - - - AND:bx ROL:bx -
RTI:i EOR:ix - - - EOR:z LSR:z - PHA:i EOR:m LSR:a - JMP:b EOR:b LSR:b -
BVC:r EOR:iy - - - EOR:zx LSR:zx - CLI:i EOR:by - - - EOR:bx LSR:bx -
RTS:i ADC:ix - - - ADC:z ROR:z - PLA:i ADC:m ROR:a - JMP:ind ADC:b ROR:b -
BVS:r ADC:iy - - - ADC:zx ROR:zx - SEI:i ADC:by - - - ADC:bx ROR:bx -
- STA:ix - - STY:z STA:z STX:z - DEY:i - TXA:i - STY:b STA:b STX:b -
BCC:r STA:iy - - STY:zx STA:zx STX:zy - TYA:i STA:by TXS:i - - STA:bx - -
LDY:m LDA:ix LDX:m - LDY:z LDA:z LDX:z - TAY:i LDA:m TAX:i - LDY:b LDA:b LDX:b -
BCS:r LDA:iy - - LDY:zx LDA:zx LDX:zy - CLV:i LDA:by TSX:i - LDY:bx LDA:bx LDX:by -
CPY:m CMP:ix - - CPY:z CMP:z DEC:z - INY:i CMP:m DEX:i - CPY:b CMP:b DEC:b -
BNE:r CMP:iy - - - CMP:zx DEC:zx - CLD:i CMP:by - - - CMP:bx DEC:bx -
CPX:m SBC:ix - - CPX:z SBC:z INC:z - INX:i SBC:m NOP:i - CPX:b SBC:b INC:b -
BEQ:r SBC:iy - - - SBC:zx INC:zx - SED:i SBC:by - - - SBC:bx INC:bx -'''.split()
assert len(rows)==256
ops=[]
for entry in rows:
 if entry=='-':ops.append(None);continue
 name,mode=entry.split(':');ops.append([name,mode,1 if mode in ['i','a'] else 3 if mode in ['b','bx','by','ind'] else 2])
start=s['famitoneinit'];end=s['_ft2dummyenvelope'];code=rom[16+start-0xc000:16+end-0xc000]
entries=[];pos=0
while pos<len(code):
 op=ops[code[pos]];assert op,(hex(start+pos),code[pos])
 name,mode,n=op;operand=int.from_bytes(code[pos+1:pos+n],'little');kind='literal';value=operand
 if mode in ['z','zx','zy','ix','iy']:
  assert 0xf0<=operand<=0xf2;kind='zp';value=operand-0xf0
 elif mode in ['b','bx','by','ind']:
  if 0x200<=operand<0x400:kind='ram';value=operand-0x300
  elif start<=operand<s['honkeypong_music_data']:kind='driver';value=operand-start
  else:assert 0x4000<=operand<=0x4017,(hex(start+pos),hex(operand))
 # The two immediate halves of the linked dummy-envelope address are relocations.
 elif mode=='m' and start+pos>=s['famitonemusicstop'] and start+pos<s['famitonemusicplay'] and code[pos]==0xa9 and operand in [s['_ft2dummyenvelope']&255,s['_ft2dummyenvelope']>>8]:
  kind='driverLow' if operand==(s['_ft2dummyenvelope']&255) else 'driverHigh';value=s['_ft2dummyenvelope']-start
 entries.append([pos,code[pos],n,kind,value]);pos+=n
assert pos==len(code)
keys=['famitoneinit','famitonemusicstop','famitonemusicplay','famitoneupdate','_ft2setinstrument','_ft2channelupdate','famitonesfxinit','famitonesfxplay','_ft2sfxupdate','_ft2dummyenvelope','_ft2notetablelsb','_ft2notetablemsb']
p={'variant':'FamiTone2 v1.11, five music channels, four SFX streams, linked no-op bank switch','source':'Shiru public-domain driver; HonkeyPong pinned source commit f9ab7ad450ffebabec15623aa811a7564f079168','codeLength':len(code),'driverLength':s['honkeypong_music_data']-start,'entries':entries,'symbols':{k:s[k]-start for k in keys},'opcodes':ops}
(root/'src/famitone2-driver-profile.js').write_text('/* Generated instruction structure; see tests/make-profile.py. No game data or recognition hash. */\n(function(root,factory){if(typeof module!=="undefined"&&module.exports)module.exports=factory();else root.FamiTone2DriverProfile=factory();})(typeof globalThis!=="undefined"?globalThis:this,function(){return '+json.dumps(p,separators=(',',':'))+';});\n')
print('Generated',len(entries),'instruction entries;',len(code),'code bytes')
