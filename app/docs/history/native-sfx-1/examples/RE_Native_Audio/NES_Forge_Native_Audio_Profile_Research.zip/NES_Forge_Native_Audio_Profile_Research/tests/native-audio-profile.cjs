'use strict';
const path=require('path'),fs=require('fs');const api=require('../src/famitone2-native.js');const result=require('./native-audio-cases.cjs')(api,path.join(__dirname,'../fixtures'));console.log(JSON.stringify(result,null,2));fs.writeFileSync(path.join(__dirname,'../evidence/standalone-contract.json'),JSON.stringify(result,null,2)+'\n');process.exitCode=result.passed?0:1;
