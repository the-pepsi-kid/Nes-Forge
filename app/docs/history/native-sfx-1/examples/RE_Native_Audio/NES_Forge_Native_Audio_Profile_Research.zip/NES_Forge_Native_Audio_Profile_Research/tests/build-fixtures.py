"""Reassemble separately labeled relocation derivatives of the real independent input."""
import hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
checkpoint=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'native-audio-discovery-2026-10-08'
spec=importlib.util.spec_from_file_location('upstream_build',checkpoint/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
_,files=b.verify_sources('HonkeyPong','honkeypong-downloads.json');b.verify_sources('Ophis','ophis-downloads.json')
out=root/'fixtures';out.mkdir(exist_ok=True);records=[]
for variant in ['independent','relocated','nrom32']:
 with tempfile.TemporaryDirectory(prefix='famitone-relocation-') as temp:
  game=Path(temp)
  for item in files:
   target=game/item['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(checkpoint/'HonkeyPong'/item['path'],target)
  for name,digest in b.EXPECTED_TABLES.items():
   source=checkpoint/'generated'/name;assert b.digest(source.read_bytes())==digest;shutil.copyfile(source,game/'res/snd'/name)
  main=game/'src/main.oph';text=main.read_text();changes=[]
  if variant=='relocated':
   text=text.replace('.include "famitone2.oph"','.advance $D000\n  .include "famitone2.oph"').replace('.include "../res/snd/HonkeyPong.oph"','.advance $D900\n  .include "../res/snd/HonkeyPong.oph"');changes=['Insert .advance $D000 before unmodified driver','Insert .advance $D900 before unmodified generated music/SFX']
  elif variant=='nrom32':
   text=text.replace('.org $C000','.org $8000');wrapper=game/'HonkeyPong_iNES.oph';wrapper.write_text(wrapper.read_text().replace('.byte $01\t\t\t; 1 16KB PRG bank','.byte $02\t\t\t; 2 16KB PRG banks'));changes=['Change PRG origin from $C000 to $8000','Change header PRG bank count from 1 to 2; retain vector fill through $FFFF']
  main.write_text(text)
  rom=out/(variant+'.nes');symbols=out/(variant+'.map');command=[sys.executable,str(checkpoint/'Ophis/bin/ophis'),'-o',str(rom),'HonkeyPong_iNES.oph','-m',str(symbols)];r=subprocess.run(command,cwd=game,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True);assert r.returncode==0,r.stderr
  data=rom.read_bytes();digest=b.digest(data)
  if variant=='independent':assert digest==b.EXPECTED_ROM
  records.append({'file':rom.name,'sha256':digest,'bytes':len(data),'classification':'unchanged independent game' if variant=='independent' else 'explicitly modified relocation derivative, same external driver and score','sourceChanges':changes,'assembler':r.stdout+r.stderr})
for src,name in [('HonkeyPong/LICENSE','LICENSE-HonkeyPong.txt'),('HonkeyPong/famitone-readme.txt','FamiTone2-upstream-readme.txt')]:shutil.copyfile(checkpoint/src,out/name)
(out/'provenance.json').write_text(json.dumps({'sourceCommit':'f9ab7ad450ffebabec15623aa811a7564f079168','sourceUrl':'https://github.com/HonkeyKong/HonkeyPong','assemblerCommit':'8873359a0913d94e56a129a6b601dfc18a6574ab','command':'python3 tests/build-fixtures.py /path/to/independent-checkpoint','fixtures':records},indent=2)+'\n')
print(json.dumps(records,indent=2))
