# FamiTone2 native recovery research checkpoint

This workspace adds a pure JavaScript decoder and bounded native ROM command editor for one source-backed FamiTone2 v1.11 linked instruction variant. It is separate from the frozen alpha.6 application. The reviewed modules are being integrated into the later alpha.7 candidate; root release reports remain authoritative for final acceptance.

The driver is independently published code, not a new Forge-specific engine. The unmodified HonkeyPong reproduction is the independent positive input. Declared source-reassembled relocated and NROM32 derivatives demonstrate recognition without game filenames, ROM hashes or fixed addresses; they are not counted as additional independent engines/games.

## Contents

- `src/famitone2-driver-profile.js`: 606 linked 6502 instructions expressed with relocated code/RAM/zero-page references and source provenance.
- `src/famitone2-native.js`: synchronous UMD/CommonJS `decode`, `patch` and SHA-256 APIs, usable without browser or Node dependencies.
- `tests/native-audio-cases.cjs`: 47 positive/negative contracts shared by standalone development and the actual bundled-HTML suite.
- `tests/native-audio-profile.cjs`: standalone development runner.
- `tests/make-profile.py`: reproduce the instruction profile from the pinned independent checkpoint.
- `tests/build-fixtures.py`: reassemble unchanged independent input and explicit relocation derivatives with pinned Ophis, retaining hashes/licenses/maps.
- `fixtures/`: ROMs, maps, original license notices and provenance.
- `evidence/`: measured contract reports and decoded native evidence. Bundled report hashes identify the candidate actually tested at that stage, not necessarily the final release candidate.

## Reproduce

Requires Node.js 20+ for pure decoder tests. The generator scripts require Python 3.8+ and the sibling native Audio input checkpoint (or pass its absolute path). They use its verified source files, generated native tables and pinned Ophis; no host binaries are retained.

```sh
python3 tests/make-profile.py /path/to/native-audio-discovery-checkpoint
python3 tests/build-fixtures.py /path/to/native-audio-discovery-checkpoint
node tests/native-audio-profile.cjs
```

For the integrated candidate, `node tests/native-audio-profile200.cjs /path/to/candidate.html /path/to/report.json` runs the same 47 contracts against the real bundled script, adds active-project/emulator nonmutation, and adds four native CPU/APU comparisons. It uses the candidate's existing emulator through its test harness. It does not append a replacement decoder or emulator.

## API and limits

`FamiTone2Native.decode(bytes)` returns `decoded`, `unknown`, `invalid` or `ambiguous`, source identity, recognition evidence, exact native music/SFX structures, limitations and diagnostics. `patch(bytes, evidence, edits)` rechecks complete-source identity and freshly decodes before applying 1–256 semantic edits to a copied ROM. Targets are song/channel/event indices; edits are `noteCode` or `instrumentId`. Only one-byte native note/cut or existing instrument commands are supported; shared aliases are reported, DPCM aliases refused, and noise aliases constrain note range. No pointer/size rewriting or canonical Audio conversion occurs.

Supported mapping: exact-length iNES NROM16/32, CHR RAM or one 8 KiB CHR bank, optional trainer. Initialization must have statically proven immediate arguments. The linked instruction configuration is deliberately narrow; other engine versions/configurations and dynamic initialization remain unknown. Music tables expose all subsongs and referenced instruments; SFX expose statically proven IDs only because the table has no count field.

The decoder preserves fixed-point tempo steps, logical row events, one-level counted references, native envelope/frame behavior, native period tables and SFX register/delay/mixing semantics. Logical rows are not a simulated global frame schedule. DPCM, inherited leading-envelope holds, nested/zero-count references, malformed/misaligned pointers, nonproductive cycles and unsupported structures are refused or explicitly retained as unsupported evidence. Per-stream bounds and a global 16,384-event budget prevent unbounded output.

Faithful conversion into Forge's canonical Audio model remains pending. The native engine's timing, per-frame envelopes, pitch tables, global speed changes, noise mode, DPCM and multichannel SFX do not automatically match Forge's current model. No audible, browser-interaction, mobile or physical-hardware acceptance is claimed by these decoder reports.

The full technical contract is copied into the integration package as `docs/NATIVE_AUDIO_PROFILE.md`; the UI workflow is independently owned in `docs/NATIVE_AUDIO_INVESTIGATION.md`.
