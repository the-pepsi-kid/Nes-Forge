Double Action Blaster Guys - independent source-intake corpus

All 44 original tracked files are byte-preserved from NovaSquirrel/DABG
commit 5ecc60b6af3f726851bfeb1c2555388c5953e0c0. The original source
manifest, intake provenance and upstream license notices are included.
The source has mixed notices; do not describe it as uniformly zlib.
No ca65/ld65 executable, rebuilt ROM or third-party toolchain is included.

This is a diagnostic input, not converted NES Forge source. The upstream
entry is dabg.s; mk.bat invokes ca65 then ld65 with nrom256.x. Source-intake
reports only inspect bytes and literal references, without running build
scripts, resolving linker symbols or evaluating macros/conditionals.

Input origin: research/native-map-intake-1/ from this repository's
previous native-map research checkpoint. Source_Files.json is the pinned
byte-level authority; Intake_Provenance.json is retained historical evidence.
