# Independent native Audio input checkpoint

This checkpoint reproduces **HonkeyPong**, an existing third-party NES game using FamiTone2. It establishes an available source-backed input for NES Forge roadmap item **Alpha A3**. It does **not** implement a decoder, import native audio into Forge, certify rebuilt sound fidelity, or complete A3 acceptance.

## Provenance and licenses

- HonkeyPong: https://github.com/HonkeyKong/HonkeyPong, commit `f9ab7ad450ffebabec15623aa811a7564f079168` (2015). All 29 downloaded files match the original Git blobs. Retain `HonkeyPong/LICENSE` (MIT, Ryan Souders) and `HonkeyPong/famitone-readme.txt` (FamiTone public-domain notice).
- Ophis: https://github.com/michaelcmartin/Ophis, commit `8873359a0913d94e56a129a6b601dfc18a6574ab`, version 2.3. The 31 downloaded assembler files are verified by `ophis-downloads.json`; retain `Ophis/LICENSE` (MIT).
- The music source credits Ryan Souders, the repository copyright holder. The game, driver, score and NSF sources are unmodified.
- The historical host `text2data.cpp` converter has memory-access and duplicate-close defects on this platform. The separately identified `text2data-compat.cpp` and `text2data-compat.patch` make four bounded corrections: room for the appended input newline, negative search-offset handling, undefined envelope-index handling, and clearing a closed file pointer. They do not change the native engine or score. Their generated tables and ROM match the historical converter's output before its exit crash.

## Reproduce the ROM

Requirements: Python 3.8+ with the standard library and a C++ compiler (`g++` by default). No network is used by these commands.

```sh
python3 build.py
```

Optional: `python3 build.py --cxx clang++ --output-dir /path/to/output`.

The script verifies source hashes and original Git blobs, copies sources into a temporary directory, compiles the compatibility music converter and the unmodified SFX converter with ordinary `-std=c++11 -O2` flags, converts the supplied music/NSF, and invokes pinned Ophis. It checks both generated audio-table hashes and the final ROM hash. Host executables are deleted with the temporary directory.

Outputs are `HonkeyPong-reproduced.nes`, `HonkeyPong-reproduced.map`, `generated/HonkeyPong.oph`, `generated/Sounds.oph`, and `build-report.json`. The report records commands, environment, verified input hashes and outcomes. A failed command returns failure and is not represented as a successful build.

Expected ROM: **24,592 bytes**, iNES, mapper 0, one 16 KiB PRG bank and one 8 KiB CHR bank.

SHA-256: `cce7bf2f71eb9e63de0dba15098679dde06a1da9d7553f2319aa60ea57a1193b`.

## Repeat the runtime observation

Requirements: Node.js 20+ and a NES Forge source package containing `source-manifest.json`, its bundled HTML, and `tests/harness.cjs`.

```sh
node probe-honkeypong.cjs /absolute/path/to/Forge/app
```

Alternatively set `FORGE_APP_DIR` and invoke the script without arguments. There is no implicit workspace path. If build outputs are elsewhere, pass that directory as the second positional argument after the app path.

The script executes the unchanged ROM in Forge's emulator and writes `HonkeyPong-runtime-probe.json`. It records the actual HTML/ROM hashes and checks natural song-0 invocation, natural gameplay calls for all three SFX IDs, tonal APU writes, zero unknown opcodes and no application errors. A passthrough observer records CPU entry points and APU writes. Ordinary Start input is used for the natural phases. Later phases are explicitly marked as diagnostic direct calls to the original 6502 music/SFX routines.

The initial observation found native song 0 at frame 5 and SFX 0/1/2 at frames 295/336/404. Frame counts are observations; the probe checks the behavior rather than treating those exact frame numbers as universal. This is logical emulator/register evidence, not audible output or physical NES acceptance.

## Proposed first decoder profile

**FamiTone2-compatible native music/SFX, statically mapped NROM, NTSC.** Recognition should use linked instruction/data structure and validated initialization pointers, never this game's filename, whole-ROM hash or fixed addresses. Resolve all pointers through validated PRG mapping and keep unsupported banking/configuration variants unknown.

Decode the music header (subsong count, instrument/sample pointers, five channel streams, PAL/NTSC tempo steps), bounded notes/cuts/repetitions/instrument/speed/loop/reference commands, eight-byte instruments, and signed/repeated/looping envelopes. Decode SFX pointer pairs and terminated register-write/delay streams. There is no explicit SFX-count field: require validated table bounds or observed calls before claiming an inventory. Keep byte-span, mapping and method provenance for each item.

For independent verification only, this ROM's source map places music at `$D3F6`, instruments at `$D417`, and the SFX table at `$D49A`. Music occupies 164 bytes; SFX data occupies 374 bytes. These are test evidence, not production recognition constants.

## Conversion and acceptance limits

- Native music uses a fixed-point frame accumulator; Forge uses integer tempo/audio ticks. Native NTSC step 238 is not exactly equivalent to Forge tempo 140.
- FamiTone envelopes advance per video frame; Forge envelopes advance per audio tick. Equal arrays do not prove equal sound.
- Derive pitches from actual channel-specific timer behavior; do not assume pulse and triangle share an octave mapping.
- Keep unsupported pitch envelopes, short-mode noise, DPCM, changing speeds and intro/loop semantics as decoded evidence; refuse conversion or clearly identify its losses.
- Native SFX can change duty/timers and multiple channels every frame. Forge's current single-channel pattern-backed SFX cannot represent all of that faithfully. This input includes such cases.

Next work is exact decoding/evidence followed by a bounded canonical conversion. HonkeyPong remains the independent real-game input and an unsupported-feature test. A separately labeled original score on this unchanged external driver can supply exact-subset positive tests. Relocated data, edited notes, Undo/save/reopen, rebuilt APU behavior and human listening remain future acceptance work.

## Files to preserve

Retain the README, `build.py`, `probe-honkeypong.cjs`, both download manifests, `HonkeyPong-provenance.json`, compatibility source/patch, the tracked `HonkeyPong` and downloaded `Ophis` source/license files, reproduced ROM/map/tables, and measured build/runtime reports. `checkpoint-files.json` explicitly lists checkpoint payload files and SHA-256 values. It excludes host executables, Python caches, initial download-discovery material and unrelated driver repositories. No frozen NES Forge application file is modified by this checkpoint.
