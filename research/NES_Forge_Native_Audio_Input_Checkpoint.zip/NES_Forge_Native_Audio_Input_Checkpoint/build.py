#!/usr/bin/env python3
"""Reproduce the independent HonkeyPong input without modifying NES Forge."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
EXPECTED_ROM = 'cce7bf2f71eb9e63de0dba15098679dde06a1da9d7553f2319aa60ea57a1193b'
EXPECTED_COMPAT = '9c9cdcfdc4c030e2f42da7bb31f0acadc3ba58506d7842a7f69799ca5ec20700'
EXPECTED_TABLES = {
    'HonkeyPong.oph': '5e1b2b6f8ddf4921a32a1d83e6b86b26c1d4829c64972ac5b86de97fa792bf6f',
    'Sounds.oph': '3ec6ead33655a6f7ddb90fa4e3b5ba0936aabd93fa5cb3dbf1ca2dc0e2206b75',
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def checked_path(base, relative):
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe manifest path: ' + str(relative))
    return base / relative

def verify_sources(directory, manifest_name):
    manifest = json.loads((ROOT / manifest_name).read_text())
    verified = []
    for item in manifest['files']:
        source = checked_path(ROOT / directory, item['path'])
        data = source.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if len(data) != item['bytes'] or digest(data) != item['sha256'] or blob != item['gitBlob']:
            raise ValueError('Source identity mismatch: ' + str(source))
        verified.append({'path': directory + '/' + item['path'], 'bytes': len(data), 'sha256': digest(data)})
    return verified, manifest['files']

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT,
                        help='Output ROM, map, generated tables and report here (default: checkpoint folder)')
    parser.add_argument('--cxx', default='g++', help='Host C++ compiler (default: g++)')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    game_verified, game_files = verify_sources('HonkeyPong', 'honkeypong-downloads.json')
    ophis_verified, _ = verify_sources('Ophis', 'ophis-downloads.json')
    compat = ROOT / 'text2data-compat.cpp'
    if digest(compat.read_bytes()) != EXPECTED_COMPAT:
        raise ValueError('Compatibility converter source identity mismatch')
    commands = []
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    def run(command, cwd):
        result = subprocess.run([str(x) for x in command], cwd=cwd, env=env,
                                text=True, capture_output=True)
        commands.append({'argv': [str(x) for x in command], 'cwd': str(cwd),
                         'exitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        if result.returncode:
            raise RuntimeError('Build command failed:\n' + ' '.join(map(str, command)) + '\n' + result.stderr)
    try:
        with tempfile.TemporaryDirectory(prefix='nesforge-famitone-input-') as temp:
            temporary = Path(temp)
            game = temporary / 'HonkeyPong'
            for item in game_files:
                target = checked_path(game, item['path'])
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(checked_path(ROOT / 'HonkeyPong', item['path']), target)
            text_tool = temporary / 'text2data'
            sfx_tool = temporary / 'nsf2data'
            run([args.cxx, '-std=c++11', '-O2', '-o', text_tool, compat], game)
            run([args.cxx, '-std=c++11', '-O2', '-o', sfx_tool, game / 'src/nsf2data.cpp'], game)
            run([text_tool, 'res/snd/HonkeyPong.txt', '-ophis'], game)
            run([sfx_tool, 'res/snd/Sounds.nsf', '-ophis'], game)
            rom = temporary / 'HonkeyPong-reproduced.nes'
            symbols = temporary / 'HonkeyPong-reproduced.map'
            run([sys.executable, ROOT / 'Ophis/bin/ophis', '-o', rom, 'HonkeyPong_iNES.oph', '-m', symbols], game)
            rom_data = rom.read_bytes()
            if digest(rom_data) != EXPECTED_ROM:
                raise ValueError('Reproduced ROM does not match expected SHA-256')
            generated = []
            for name, expected in EXPECTED_TABLES.items():
                source = game / 'res/snd' / name
                if digest(source.read_bytes()) != expected:
                    raise ValueError('Generated audio table mismatch: ' + name)
                (output / 'generated').mkdir(exist_ok=True)
                shutil.copyfile(source, output / 'generated' / name)
                generated.append({'path': 'generated/' + name, 'sha256': expected})
            shutil.copyfile(rom, output / rom.name)
            shutil.copyfile(symbols, output / symbols.name)
            report = {'kind': 'HonkeyPong independent-input reproduction', 'passed': True,
                      'scope': 'Independent source build only; no Forge decoder/import or audible acceptance.',
                      'sourceCommit': 'f9ab7ad450ffebabec15623aa811a7564f079168',
                      'ophisCommit': '8873359a0913d94e56a129a6b601dfc18a6574ab',
                      'compatibilitySourceSha256': EXPECTED_COMPAT,
                      'environment': {'python': sys.version, 'platform': platform.platform()},
                      'commands': commands, 'verifiedInputs': game_verified + ophis_verified,
                      'rom': {'file': rom.name, 'bytes': len(rom_data), 'sha256': EXPECTED_ROM},
                      'generated': generated, 'compiledHostExecutablesRetained': False}
            (output / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
    except Exception as error:
        (output / 'build-report.json').write_text(json.dumps({'passed': False, 'error': str(error), 'commands': commands}, indent=2) + '\n')
        raise
    print('PASS: reproduced 24,592-byte ROM ' + EXPECTED_ROM)
    print('All 29 HonkeyPong and 31 Ophis source files verified; temporary host executables removed.')

if __name__ == '__main__':
    main()
