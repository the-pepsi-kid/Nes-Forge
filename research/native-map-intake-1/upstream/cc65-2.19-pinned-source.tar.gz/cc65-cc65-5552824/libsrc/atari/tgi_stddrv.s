;
; Name of the standard tgi driver
;
; Oliver Schmidt, 2011-05-02
;
; const char tgi_stddrv[];
;

        .export _tgi_stddrv

.rodata

_tgi_stddrv:
        .ifdef  __ATARIXL__
                .asciiz "atrx8.tgi"
        .else
                .asciiz "atr8.tgi"
        .endif
