# NES Forge — RC2 Build 5 Public Review Candidate 1

**Source:** RC2 Build 5 at local integration commit `91d9f767` (owner-held archive).  
**Public derivative editor SHA-256:** `c8f1871bc919adaab25c763820b3818ac61b5307bb67993f7a4ef41dae9da481`  
**Status:** *experimental sanitized derivative for review*, not official RC2 and not a public release.

## Run
Open `NES_Forge.html` in modern Edge/Chrome, or serve it from localhost if browser file restrictions interfere. Test only your own original or authorized game assets.

## What's included
- Exactly 214 JavaScript/HTML parts, ordered by `app/source-manifest.json`.
- One generated offline editor (`NES_Forge.html`), checksum and deterministic bundler.
- Source files for auditing/rebuilding without requiring proprietary ROMs.

## Deliberately removed
The original archive's `Recovery_Evidence/` tree and all historical review logs, private experiments, private hosted-world bundles and ROM-derived media. Two compressed Castlevania catalogs are replaced with inert interfaces. **Exact matched Castlevania automatic scene recovery is therefore disabled in this derivative**, while ordinary ROM inspection and Forge authoring remain available.

## Provenance and limitations
This is **not byte-identical** to original RC2, and cannot be represented as a tested canonical RC2 Build 5. It has not been confirmed rights-cleared for broad commercial redistribution; additional legal/asset review is needed for research-derived game-specific tables and documentation.

The original recovery archive remains private. Never merge the private evidence folder into a public repo.

## Regenerate
`python3 app/tools/bundle.py` then `python3 app/tools/bundle.py --check`.

## Testing
See `PUBLIC_RELEASE_MANIFEST.json` for identity and recorded exclusions. Any inherited RC2 test report is historical; only rerun tests against this derivative count as fresh evidence.
