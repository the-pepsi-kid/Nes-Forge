/* NES Forge public review: original Castlevania scene payloads intentionally omitted.
 * Manual user-owned ROM import, generic inspection and runtime capture remain available. */
(()=>{'use strict';
window.Forge=window.Forge||{};window.Forge.services=window.Forge.services||{};
window.Forge.services.RecoveryCatalog=Object.freeze({
  find(){return null;},info(){return null;},
  async project(){throw Error('Original-game recovery snapshots are excluded from this public build. Use private, rights-authorized recovery evidence.');}
});
})();
