/* NES Forge public review: embedded raw original-ROM capture streams intentionally omitted. */
(()=>{'use strict';
window.Forge=window.Forge||{};window.Forge.services=window.Forge.services||{};
window.Forge.services.RecoveryEvidenceCatalog=Object.freeze({
  list(){return [];},
  async get(){throw Error('Private ROM-derived capture data are not included in the public edition.');}
});
})();
