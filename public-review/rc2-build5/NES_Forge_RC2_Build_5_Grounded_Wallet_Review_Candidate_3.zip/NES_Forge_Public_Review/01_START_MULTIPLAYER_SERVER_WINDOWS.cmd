@echo off
cd /d "%~dp0"
call START_LOCALHOST_WINDOWS.cmd
