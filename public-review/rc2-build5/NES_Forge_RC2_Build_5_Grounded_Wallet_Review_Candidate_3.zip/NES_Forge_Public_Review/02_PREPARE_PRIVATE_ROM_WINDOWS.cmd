@echo off
setlocal
cd /d "%~dp0"
echo Local original-ROM asset preparation. Requires Python 3.11+ and Playwright Chromium.
set /p "ROM_PATH=Full path to your private Zelda II US ROM: "
set /p "ADMIN_TOKEN=Current localhost admin token: "
py PREPARE_PRIVATE_Z2_DEMO.py --rom "%ROM_PATH%" --admin-token "%ADMIN_TOKEN%"
pause
