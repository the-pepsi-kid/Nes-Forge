NES Forge Native Game RE review kit

Extract the entire ZIP to C:/NF/Ninja_Zelda_RE or another short location. Open START_HERE.html, then Open NES Forge. NES_Forge.html is the complete standalone app.

RE / DISASM > Open spatial RE workbench. Choose your own investigated Ninja Gaiden or Zelda II ROM once. Read Native_Game_RE_Guide.html for controls, exact coverage and gaps. The catalog is read-only; full playable conversion and complete collision/AI/physics are not implemented.

All earlier tools, original tutorials, manual styles and examples are retained. No commercial ROM or extracted commercial asset payload is included. RC3/RC4/RC5 preserve predecessor content. Run python verify_kit.py for the packaged inventory.
