from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'CONTENT_INVENTORY.json').read_text())
for item in manifest['files']:
 p=root/item['path'];assert p.is_file(),item['path'];assert p.stat().st_size==item['bytes'],item['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
print('Verified',len(manifest['files']),'packaged payloads')
