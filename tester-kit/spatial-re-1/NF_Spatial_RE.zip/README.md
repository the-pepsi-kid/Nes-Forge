NES Forge Spatial RE review kit

Extract the entire ZIP to C:/NF or another short path. Open START_HERE.html, then Open NES Forge. The actual self-contained app is NES_Forge.html.

RE / DISASM > Open spatial RE workbench. Choose your own investigated ROM. Read Spatial_RE_Guide.html for per-game support, every control and limits. Native scene import and complete behavior reconstruction are not implemented in this checkpoint.

All earlier audio guides, original tutorials and examples are retained. Supplied commercial ROMs/sample payloads are excluded. RC3 preserves the original kit; RC4 preserves replaced predecessor launch/metadata files. Run python verify_kit.py to check the packaged files.
