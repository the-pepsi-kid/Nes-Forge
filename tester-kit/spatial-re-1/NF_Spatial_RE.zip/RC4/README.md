NES Forge Mega Man 2 Audio review kit

Mega Man 2 US now populates Native Cue. Open AUDIO > ROM Audio Library > Open NES ROM and select your own ROM. Read Mega_Man_2_Audio.html for all formats, controls, aliases and limits. Source ROM is excluded.

On Windows, extract the entire ZIP to a short path such as C:/NF. Open START_HERE.html, then Open NES Forge. NES_Forge.html is the actual self-contained app.

For unknown drivers, open AUDIO > ROM Audio Library. Use Open ROM for discovery for static investigation, including unsupported mappers. Load a supported source in the emulator before bounded recording. Start with examples/Audio_Discovery/Discovery_NROM.nes. Read Audio_Discovery_Guide.html for every control, evidence label and limit.

The earlier known-ROM workflow is documented in Native_Audio_Guide.html. Original guides, game tutorial, manual PDFs and examples remain available. The complete original kit is retained under RC3/. Supplied commercial ROM/sample payloads are excluded.

Run python verify_kit.py after extraction to check packaged files and the exact app.
