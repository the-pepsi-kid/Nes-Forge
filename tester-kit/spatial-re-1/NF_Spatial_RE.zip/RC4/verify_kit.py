from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
manifest=json.loads((r/'CONTENT_INVENTORY.json').read_text())
for x in manifest['files']:
 p=r/x['path'];assert p.is_file(),x['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['path']
s=json.loads((r/'SOURCE_RECORD.json').read_text());assert hashlib.sha256((r/s['html']).read_bytes()).hexdigest()==s['htmlSha256']
print('Verified',len(manifest['files']),'files and exact Mega Man 2 Audio application.')
