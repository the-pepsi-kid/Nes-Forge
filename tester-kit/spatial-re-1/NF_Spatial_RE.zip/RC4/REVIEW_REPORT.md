# Audio Discovery review kit

Open START_HERE.html. The actual application is included as NES_Forge.html. Current measured verification is in VERIFICATION.json; the Mega Man 2 tutorial is Mega_Man_2_Audio.html; unknown-ROM investigation guide is Audio_Discovery_Guide.html; the known-ROM conversion guide is Native_Audio_Guide.html. Earlier guides and examples remain available.
