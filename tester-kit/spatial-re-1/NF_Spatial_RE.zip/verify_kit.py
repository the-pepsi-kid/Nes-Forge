from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/"CONTENT_INVENTORY.json").read_text())
for x in m["files"]:
 p=r/x["path"];assert p.is_file(),x["path"];assert hashlib.sha256(p.read_bytes()).hexdigest()==x["sha256"],x["path"]
s=json.loads((r/"SOURCE_RECORD.json").read_text());assert hashlib.sha256((r/s["html"]).read_bytes()).hexdigest()==s["htmlSha256"]
print("Verified",len(m["files"]),"files and exact Spatial RE app.")
